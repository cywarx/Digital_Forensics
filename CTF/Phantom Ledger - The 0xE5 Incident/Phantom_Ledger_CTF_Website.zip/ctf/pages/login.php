<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';

redirect_if_logged_in();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_ok()) {
        $error = 'Invalid request. Please try again.';
    } else {
        $res = attempt_login($_POST['username'] ?? '', $_POST['password'] ?? '');
        if ($res['ok']) {
            if ($res['user']['role'] === 'admin')
                header('Location: ' . BASE_URL . '/pages/admin/index.php');
            else
                header('Location: ' . BASE_URL . '/pages/dashboard.php');
            exit;
        }
        $error = $res['error'];
    }
}
auth_head('Login');
?>
<div class="auth-wrap">
  <div class="auth-box">
    <div class="auth-logo-wrap">
      <div class="auth-logo">CY<span>WARX</span></div>
      <div class="auth-tagline">Digital Forensics CTF</div>
    </div>
    <form class="auth-form" method="POST">
      <?= csrf_field() ?>
      <h3 style="font-size:15px;color:var(--txt2);font-weight:500;">Sign in to your account</h3>
      <?php if ($error): ?>
        <div class="alert error"><?= e($error) ?></div>
      <?php endif; ?>
      <div class="field">
        <label>Username</label>
        <input type="text" name="username" placeholder="Enter your username"
               value="<?= e($_POST['username'] ?? '') ?>" autocomplete="username" required>
      </div>
      <div class="field">
        <label>Password</label>
        <input type="password" name="password" placeholder="Enter your password"
               autocomplete="current-password" required>
      </div>
      <button type="submit" class="btn btn-primary btn-block">Sign In</button>
    </form>
    <div class="auth-footer">
      Don't have an account? <a href="<?= BASE_URL ?>/pages/signup.php">Create one here</a>
    </div>
  </div>
</div>
<?php auth_foot(); ?>
