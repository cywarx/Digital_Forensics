<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/challenges.php';
require_once __DIR__ . '/../includes/layout.php';

header('Content-Type: application/json');
$user = current_user();
if (!$user) { echo json_encode(['error'=>'Not logged in']); exit; }

$id = (int)($_GET['id'] ?? 0);
$ch = get_challenge($id);
if (!$ch) { echo json_encode(['error'=>'Not found']); exit; }

$solved        = in_array($id, solved_ids((int)$user['id']));
$diff          = DIFF_META[$ch['difficulty']] ?? DIFF_META['EASY'];
$hint_on       = (int)($ch['hint_enabled'] ?? 0) === 1;

echo json_encode([
    'ch'          => [
        'id'        => $ch['id'],
        'title'     => $ch['title'],
        'topic'     => $ch['topic'],
        'points'    => $ch['points'],
        'accent'    => $ch['accent'],
        'real_case' => $ch['real_case'],
        'story'     => $ch['story'],
        'hint'      => $hint_on ? $ch['hint'] : null,  // never sent when locked
        'diff_badge'=> '<span class="badge '.$diff['cls'].'">'.$diff['label'].'</span>',
    ],
    'hint_enabled' => $hint_on,   // per-challenge flag
    'solved'       => $solved,
]);
