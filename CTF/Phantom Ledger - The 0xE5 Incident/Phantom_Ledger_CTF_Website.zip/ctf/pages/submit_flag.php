<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/challenges.php';

header('Content-Type: application/json');

$user = current_user();
if (!$user || $user['role'] === 'admin') {
    echo json_encode(['ok'=>false,'error'=>'Not authenticated.']); exit;
}
if (!csrf_ok()) {
    echo json_encode(['ok'=>false,'error'=>'Invalid request.']); exit;
}

$challengeId = (int)($_POST['challenge_id'] ?? 0);
$flag        = trim($_POST['flag'] ?? '');

if (!$challengeId || !$flag) {
    echo json_encode(['ok'=>false,'error'=>'Missing data.']); exit;
}

$result = submit_flag((int)$user['id'], $challengeId, $flag);
if ($result['ok']) {
    $result['total_pts'] = user_pts((int)$user['id']);
}
echo json_encode($result);
