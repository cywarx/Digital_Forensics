<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/challenges.php';
require_once __DIR__ . '/../includes/layout.php';

$user  = require_student();
$board = scoreboard();
$total = total_pts();
$myId  = (int)$user['id'];

html_head('Leaderboard');
top_nav($user, 'leaderboard');
?>
<div class="page">
  <div class="page-header">
    <h2>Leaderboard</h2>
    <span style="font-size:12px;color:var(--txt2);">Max score: <?= $total ?> pts</span>
  </div>

  <div class="card">
    <div class="card-body">
      <?php if (empty($board)): ?>
        <div style="text-align:center;padding:30px;color:var(--txt2);">No participants yet.</div>
      <?php else: ?>
        <?php
        $posClass = ['g','s','b'];
        foreach ($board as $i => $row):
          $isMe = (int)$row['id'] === $myId;
          $pct  = $total > 0 ? min(100, round($row['pts']/$total*100)) : 0;
        ?>
        <div class="lb-item <?= $isMe ? 'lb-you' : '' ?>">
          <span class="lb-pos <?= $posClass[$i] ?? '' ?>"><?= $i+1 ?></span>
          <div style="display:flex;align-items:center;gap:9px;flex:1;min-width:0;">
            <span class="avatar"><?= initials($row['full_name']) ?></span>
            <div>
              <div class="lb-name">
                <?= e($row['full_name']) ?>
                <?php if ($isMe): ?>
                  <span style="font-family:var(--fm);font-size:10px;color:var(--blue);margin-left:6px;">(you)</span>
                <?php endif; ?>
              </div>
              <div class="lb-meta">@<?= e($row['username']) ?> &nbsp;·&nbsp; <?= $row['solved'] ?> solved</div>
            </div>
          </div>
          <div class="prog-row" style="width:160px;">
            <?= progress_bar((int)$row['pts'], $total) ?>
            <span class="prog-pct"><?= $pct ?>%</span>
          </div>
          <span class="lb-score"><?= $row['pts'] ?> pts</span>
        </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php html_foot(); ?>
