<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/challenges.php';
require_once __DIR__ . '/../../includes/layout.php';

$user  = require_admin();
$error = '';
$ok    = '';

// ── Handle POST actions ──────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && csrf_ok()) {

    $action = $_POST['action'] ?? '';

    // Add student
    if ($action === 'add') {
        $res = attempt_register(
            $_POST['full_name'] ?? '',
            $_POST['username']  ?? '',
            $_POST['password']  ?? ''
        );
        if ($res['ok']) {
            // Ensure they're logged in as the NEW student doesn't hijack admin session
            unset($_SESSION['uid']);
            $_SESSION['uid'] = $user['id']; // restore admin
            $ok = 'Student "' . htmlspecialchars($_POST['full_name']) . '" added successfully.';
        } else {
            $error = $res['error'];
        }
    }

    // Reset password
    if ($action === 'reset_pw') {
        $uid  = (int)($_POST['uid'] ?? 0);
        $pass = trim($_POST['new_password'] ?? '');
        if ($uid && strlen($pass) >= 6) {
            $hash = password_hash($pass, PASSWORD_BCRYPT, ['cost'=>12]);
            db()->prepare('UPDATE users SET password=? WHERE id=? AND role="student"')
               ->execute([$hash, $uid]);
            $ok = 'Password reset successfully.';
        } else {
            $error = 'Password must be at least 6 characters.';
        }
    }

    // Remove student
    if ($action === 'remove') {
        $uid = (int)($_POST['uid'] ?? 0);
        if ($uid) {
            db()->prepare('DELETE FROM users WHERE id=? AND role="student"')
               ->execute([$uid]);
            $ok = 'Student account removed.';
        }
    }
}

$board    = scoreboard();
$students = db()->query("SELECT * FROM users WHERE role='student' ORDER BY joined_at DESC")->fetchAll();

html_head('Students');
top_nav($user, 'students');
?>
<div class="page">
  <div class="page-header">
    <h2>Student Accounts</h2>
    <button class="btn btn-primary btn-sm" onclick="openModal('add-student')">+ Add Student</button>
  </div>

  <?php if ($ok):    echo '<div class="alert success">'.e($ok).'</div>'; endif; ?>
  <?php if ($error): echo '<div class="alert error">'.e($error).'</div>'; endif; ?>

  <div class="tbl-wrap">
    <div class="tbl-top">
      <span style="font-weight:700;font-size:14px;">Students (<?= count($students) ?>)</span>
      <input class="search" type="text" placeholder="Search name or username…"
             oninput="filterTable(this,'students-tbody')">
    </div>
    <table>
      <thead>
        <tr>
          <th>#</th><th>Name</th><th>Username</th>
          <th>Joined</th><th>Solved</th><th>Points</th><th>Actions</th>
        </tr>
      </thead>
      <tbody id="students-tbody">
        <?php if (empty($students)): ?>
          <tr><td colspan="7" style="text-align:center;color:var(--txt2);padding:24px;">
            No students registered yet.
          </td></tr>
        <?php else: ?>
          <?php foreach ($students as $i => $s):
            $row = array_filter($board, fn($r)=> (int)$r['id']===(int)$s['id']);
            $row = reset($row);
            $solved = $row ? $row['solved'] : 0;
            $pts    = $row ? $row['pts']    : 0;
          ?>
          <tr>
            <td style="font-family:var(--fm);color:var(--txt2);font-size:11px;">
              <?= str_pad($i+1,2,'0',STR_PAD_LEFT) ?>
            </td>
            <td>
              <div style="display:flex;align-items:center;gap:8px;">
                <span class="avatar" style="font-size:10px;"><?= initials($s['full_name']) ?></span>
                <span style="font-weight:600;"><?= e($s['full_name']) ?></span>
              </div>
            </td>
            <td style="font-family:var(--fm);font-size:12px;color:var(--txt2);">
              @<?= e($s['username']) ?>
            </td>
            <td style="font-size:12px;color:var(--txt2);"><?= fmt_dt($s['joined_at']) ?></td>
            <td style="font-family:var(--fm);"><?= $solved ?> / <?= count(get_challenges()) ?></td>
            <td style="font-family:var(--fm);color:var(--blue);font-weight:600;"><?= $pts ?></td>
            <td>
              <div style="display:flex;gap:5px;flex-wrap:wrap;align-items:center;">
                <button class="btn btn-xs"
                        style="background:var(--blue-bg);border:1px solid var(--blue-br);color:var(--blue);"
                        onclick="openProgress(<?= $s['id'] ?>)">📊 Progress</button>
                <button class="btn btn-outline btn-xs"
                        onclick="openResetPw(<?= $s['id'] ?>,'<?= e(addslashes($s['full_name'])) ?>')">Reset PW</button>
                <button class="btn btn-danger btn-xs"
                        onclick="openRemove(<?= $s['id'] ?>,'<?= e(addslashes($s['full_name'])) ?>')">Remove</button>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Add Student Modal -->
<div class="modal-bg" id="modal-add-student">
  <div class="modal">
    <div class="modal-head">
      <h3>Add New Student</h3>
      <button class="modal-close" onclick="closeModal('add-student')">✕</button>
    </div>
    <form method="POST">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="add">
      <div class="modal-body">
        <div class="field"><label>Full Name</label>
          <input type="text" name="full_name" placeholder="e.g. Priya Sharma" required></div>
        <div class="field"><label>Username</label>
          <input type="text" name="username" placeholder="letters, numbers, underscores" required></div>
        <div class="field"><label>Password</label>
          <input type="text" name="password" placeholder="Min 6 characters" required></div>
      </div>
      <div class="modal-foot">
        <button type="button" class="btn btn-outline" onclick="closeModal('add-student')">Cancel</button>
        <button type="submit" class="btn btn-primary">Add Student</button>
      </div>
    </form>
  </div>
</div>

<!-- Reset Password Modal -->
<div class="modal-bg" id="modal-reset-pw">
  <div class="modal">
    <div class="modal-head">
      <h3>Reset Password</h3>
      <button class="modal-close" onclick="closeModal('reset-pw')">✕</button>
    </div>
    <form method="POST">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="reset_pw">
      <input type="hidden" name="uid" id="reset-uid">
      <div class="modal-body">
        <p style="font-size:13px;color:var(--txt2);">
          Resetting password for: <strong id="reset-name"></strong>
        </p>
        <div class="field"><label>New Password</label>
          <input type="text" name="new_password" id="reset-pw" placeholder="Min 6 characters" required></div>
      </div>
      <div class="modal-foot">
        <button type="button" class="btn btn-outline" onclick="closeModal('reset-pw')">Cancel</button>
        <button type="submit" class="btn btn-amber">Reset Password</button>
      </div>
    </form>
  </div>
</div>

<!-- Remove Student Modal -->
<div class="modal-bg" id="modal-remove">
  <div class="modal">
    <div class="modal-head">
      <h3>Remove Student</h3>
      <button class="modal-close" onclick="closeModal('remove')">✕</button>
    </div>
    <form method="POST">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="remove">
      <input type="hidden" name="uid" id="remove-uid">
      <div class="modal-body">
        <div class="danger-box">
          ⚠ You are about to permanently delete the account for
          <strong id="remove-student-name"></strong> and all their submissions.
          This cannot be undone.
        </div>
      </div>
      <div class="modal-foot">
        <button type="button" class="btn btn-outline" onclick="closeModal('remove')">Cancel</button>
        <button type="submit" class="btn btn-danger">Delete Account</button>
      </div>
    </form>
  </div>
</div>

<?php include __DIR__ . '/partials/progress_modal.php'; ?>
<script>
const BASE_URL   = '<?= BASE_URL ?>';
const CSRF_TOKEN = '<?= csrf_token() ?>';
</script>
<?php html_foot(); ?>
