<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/challenges.php';
require_once __DIR__ . '/../../includes/layout.php';

$user  = require_admin();
$board = scoreboard();
$total = total_pts();
$subs  = db()->query('SELECT user_id, MAX(submitted_at) AS last FROM submissions GROUP BY user_id')
             ->fetchAll(PDO::FETCH_KEY_PAIR);

html_head('Scoreboard');
top_nav($user, 'scoreboard');
?>
<div class="page">
  <div class="page-header">
    <h2>Full Scoreboard</h2>
    <span style="font-size:12px;color:var(--txt2);">Max score: <?= $total ?> pts &nbsp;·&nbsp;
      Click any row to view that student's progress</span>
  </div>

  <div class="tbl-wrap">
    <table>
      <thead>
        <tr>
          <th>Rank</th><th>Student</th><th>Solved</th>
          <th>Points</th><th>Completion</th><th>Last Activity</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($board)): ?>
          <tr><td colspan="6" style="text-align:center;color:var(--txt2);padding:24px;">
            No students yet.</td></tr>
        <?php else: ?>
          <?php
          $rankCls = ['rank-gold','rank-silver','rank-bronze'];
          foreach ($board as $i => $row):
            $pct = $total > 0 ? min(100,round($row['pts']/$total*100)) : 0;
            $la  = $subs[$row['id']] ?? null;
          ?>
          <tr style="cursor:pointer;" onclick="openProgress(<?= $row['id'] ?>)"
              title="Click to view progress for <?= e($row['full_name']) ?>">
            <td style="font-family:var(--fm);font-weight:700;<?= match($i){0=>'color:#ffd700',1=>'color:#c0c0c0',2=>'color:#cd7f32',default=>''} ?>">
              <?= $i+1 ?>
            </td>
            <td style="font-weight:600;">
              <?= e($row['full_name']) ?>
              <span style="font-family:var(--fm);font-size:11px;color:var(--txt2);">
                @<?= e($row['username']) ?>
              </span>
            </td>
            <td style="font-family:var(--fm);">
              <strong><?= $row['solved'] ?></strong>
              <span style="color:var(--txt3);"> / <?= count(get_challenges()) ?></span>
            </td>
            <td style="font-family:var(--fm);font-weight:700;color:var(--blue);"><?= $row['pts'] ?></td>
            <td style="min-width:140px;">
              <div class="prog-row">
                <?= progress_bar((int)$row['pts'], $total) ?>
                <span class="prog-pct"><?= $pct ?>%</span>
              </div>
            </td>
            <td style="font-size:12px;color:var(--txt2);"><?= fmt_dt($la) ?></td>
          </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include __DIR__ . '/partials/progress_modal.php'; ?>
<script>
const BASE_URL   = '<?= BASE_URL ?>';
const CSRF_TOKEN = '<?= csrf_token() ?>';
</script>
<?php html_foot(); ?>
