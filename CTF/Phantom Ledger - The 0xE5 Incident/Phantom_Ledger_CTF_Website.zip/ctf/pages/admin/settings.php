<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/challenges.php';
require_once __DIR__ . '/../../includes/layout.php';

$user  = require_admin();
$ok    = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && csrf_ok()) {
    $filename = trim($_POST['image_filename'] ?? '');
    $hash     = trim($_POST['image_sha256']   ?? '');
    if ($filename) { set_setting('image_filename', $filename); }
    if ($hash)     { set_setting('image_sha256',   $hash); }
    $ok = 'Settings saved successfully.';
}

$imgFile = get_setting('image_filename', 'ctf1.img');
$imgHash = get_setting('image_sha256',   '');

html_head('Settings');
top_nav($user, 'settings');
?>
<div class="page">
  <div class="page-header"><h2>Settings</h2></div>

  <?php if ($ok):    echo '<div class="alert success">'.e($ok).'</div>'; endif; ?>
  <?php if ($error): echo '<div class="alert error">'.e($error).'</div>'; endif; ?>

  <div class="card" style="max-width:560px;">
    <div class="card-head"><h3>Evidence Image</h3></div>
    <div class="card-body">
      <p style="font-size:13px;color:var(--txt2);margin-bottom:16px;line-height:1.6;">
        Set the canonical image filename and SHA-256 hash. Students will see this on their
        dashboard as a verification step before they begin.
        <br><br>
        Generate the hash with: <code>sha256sum ctf1.img</code>
      </p>
      <form method="POST" class="form-stack">
        <?= csrf_field() ?>
        <div class="field">
          <label>Image Filename</label>
          <input type="text" name="image_filename"
                 value="<?= e($imgFile) ?>" placeholder="ctf1.img">
        </div>
        <div class="field">
          <label>SHA-256 Hash</label>
          <input type="text" name="image_sha256"
                 value="<?= e($imgHash) ?>"
                 placeholder="Paste sha256sum output here"
                 style="font-family:var(--fm);font-size:12px;">
          <span class="field-hint">
            Students will compare their local hash against this value to confirm
            they have the correct image.
          </span>
        </div>
        <div>
          <button type="submit" class="btn btn-primary">Save Settings</button>
        </div>
      </form>
    </div>
  </div>

  <div class="card" style="max-width:560px;margin-top:16px;">
    <div class="card-head"><h3>Admin Password</h3></div>
    <div class="card-body">
      <p style="font-size:13px;color:var(--txt2);margin-bottom:16px;line-height:1.6;">
        To change the admin password, update <code>includes/config.php</code> and
        re-run the installer, or update the hash directly in MySQL:
      </p>
      <pre style="background:var(--raised);border:1px solid var(--border);border-radius:var(--rsm);
                  padding:12px;font-family:var(--fm);font-size:12px;color:var(--green);
                  overflow-x:auto;line-height:1.7;">UPDATE users
SET password = '$2y$12$...'
WHERE username = 'admin';

-- Generate hash with PHP:
-- echo password_hash('NewPassword', PASSWORD_BCRYPT);</pre>
    </div>
  </div>
</div>
<?php html_foot(); ?>
