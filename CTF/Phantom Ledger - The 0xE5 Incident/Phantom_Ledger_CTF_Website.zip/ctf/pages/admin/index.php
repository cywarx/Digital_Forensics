<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/challenges.php';
require_once __DIR__ . '/../../includes/layout.php';

$user    = require_admin();
$board   = scoreboard();
$subs    = recent_subs(12);
$allCh   = get_challenges();
$allUsers= db()->query("SELECT * FROM users WHERE role='student' ORDER BY joined_at DESC")->fetchAll();
$totalSolves   = (int)db()->query("SELECT COUNT(*) FROM submissions WHERE is_correct=1")->fetchColumn();
$totalAttempts = (int)db()->query("SELECT COUNT(*) FROM submissions")->fetchColumn();

html_head('Admin Overview');
top_nav($user, 'overview');
?>
<div class="page">
  <div class="page-header"><h2>Dashboard Overview</h2></div>

  <!-- Stats -->
  <div class="stat-grid">
    <div class="stat-card" style="--c:var(--blue)">
      <div class="stat-val"><?= count($allUsers) ?></div>
      <div class="stat-lbl">Total Students</div>
    </div>
    <div class="stat-card" style="--c:var(--green)">
      <div class="stat-val"><?= $totalSolves ?></div>
      <div class="stat-lbl">Correct Solves</div>
    </div>
    <div class="stat-card" style="--c:var(--amber)">
      <div class="stat-val"><?= $totalAttempts ?></div>
      <div class="stat-lbl">Total Submissions</div>
    </div>
    <div class="stat-card" style="--c:var(--purple)">
      <div class="stat-val"><?= count($allCh) ?></div>
      <div class="stat-lbl">Challenges</div>
    </div>
    <div class="stat-card" style="--c:var(--orange)">
      <div class="stat-val"><?= total_pts() ?></div>
      <div class="stat-lbl">Max Possible Pts</div>
    </div>
  </div>

  <!-- Top 5 -->
  <div class="card" style="margin-bottom:16px;">
    <div class="card-head">
      <h3>Top Students</h3>
      <a href="<?= BASE_URL ?>/pages/admin/scoreboard.php"
         class="btn btn-ghost btn-sm" style="margin-left:auto;">View All →</a>
    </div>
    <div class="card-body">
      <?php if (empty($board)): ?>
        <div style="color:var(--txt2);font-size:13px;">No students yet.</div>
      <?php else: ?>
        <?php $icons=['🥇','🥈','🥉'];
        foreach (array_slice($board,0,5) as $i=>$row): ?>
          <div style="display:flex;align-items:center;gap:12px;padding:8px 0;
                      border-bottom:1px solid var(--border);cursor:pointer;"
               onclick="openProgress(<?= $row['id'] ?>)">
            <span style="font-size:16px;width:24px;"><?= $icons[$i] ?? ($i+1) ?></span>
            <span style="flex:1;font-weight:600;"><?= e($row['full_name']) ?></span>
            <span style="font-family:var(--fm);font-size:12px;color:var(--txt2);"><?= $row['solved'] ?> solved</span>
            <span style="font-family:var(--fm);font-size:14px;font-weight:700;color:var(--blue);"><?= $row['pts'] ?> pts</span>
            <span style="font-family:var(--fm);font-size:10px;color:var(--blue);opacity:.7;">View →</span>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </div>

  <!-- Recent submissions -->
  <div class="tbl-wrap">
    <div class="tbl-top"><span style="font-weight:700;font-size:14px;">Recent Submissions</span></div>
    <table>
      <thead>
        <tr><th>Time</th><th>Student</th><th>Challenge</th><th>Result</th></tr>
      </thead>
      <tbody>
        <?php if (empty($subs)): ?>
          <tr><td colspan="4" style="text-align:center;color:var(--txt2);padding:20px;">No submissions yet.</td></tr>
        <?php else: ?>
          <?php foreach ($subs as $s): ?>
            <tr>
              <td style="font-family:var(--fm);font-size:11px;color:var(--txt2);"><?= fmt_dt($s['submitted_at']) ?></td>
              <td style="cursor:pointer;color:var(--blue);" onclick="openProgress(<?= $s['user_id'] ?>)">
                <?= e($s['full_name']) ?>
              </td>
              <td><?= e($s['ch_title']) ?></td>
              <td><?= $s['is_correct']
                    ? '<span class="badge badge-green">✓ Correct</span>'
                    : '<span class="badge badge-red">✗ Wrong</span>' ?></td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include __DIR__ . '/partials/progress_modal.php'; ?>
<script>
const BASE_URL   = '<?= BASE_URL ?>';
const CSRF_TOKEN = '<?= csrf_token() ?>';
</script>
<?php html_foot(); ?>
