<?php
// ==========================================================
//  CYWARX CTF — Admin: Per-Challenge Hint Toggle (AJAX)
//  POST  challenge_id=<int> + csrf=<token>
//  Returns JSON { id, hint_enabled }
// ==========================================================
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/challenges.php';

header('Content-Type: application/json');

// Admin only
$user = current_user();
if (!$user || $user['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['error' => 'Forbidden']);
    exit;
}

// CSRF check
if (!csrf_ok()) {
    http_response_code(419);
    echo json_encode(['error' => 'Invalid CSRF token']);
    exit;
}

$id = (int)($_POST['challenge_id'] ?? 0);
if ($id <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid challenge_id']);
    exit;
}

// Verify challenge exists
$ch = get_challenge($id);
if (!$ch) {
    http_response_code(404);
    echo json_encode(['error' => 'Challenge not found']);
    exit;
}

// Flip the flag and return new state
$new_state = toggle_challenge_hint($id);

echo json_encode([
    'id'           => $id,
    'hint_enabled' => $new_state,   // 0 or 1
]);
