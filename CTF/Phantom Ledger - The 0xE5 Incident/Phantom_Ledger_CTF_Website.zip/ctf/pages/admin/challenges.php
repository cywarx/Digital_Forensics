<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/challenges.php';
require_once __DIR__ . '/../../includes/layout.php';

$user       = require_admin();
$challenges = get_challenges();
$counts     = solve_counts();

html_head('Challenges');
top_nav($user, 'challenges');
?>
<div class="page">
  <div class="page-header">
    <h2>Challenge Reference</h2>
    <span style="font-size:12px;color:var(--txt2);">
      Flags visible to admin only &nbsp;·&nbsp;
      Hint toggle unlocks per-challenge hint for students
    </span>
  </div>

  <!-- Quick legend -->
  <div style="display:flex;align-items:center;gap:16px;margin-bottom:14px;
              font-size:12px;color:var(--txt2);">
    <span>💡 Hint toggle:</span>
    <span class="hint-pill hint-pill-on">🔓 Unlocked — students can see hint</span>
    <span class="hint-pill hint-pill-off">🔒 Locked — hint hidden from students</span>
  </div>

  <div class="tbl-wrap">
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>Title</th>
          <th>Topic</th>
          <th>Difficulty</th>
          <th>Points</th>
          <th>Solves</th>
          <th>Hint</th>
          <th>Flag</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($challenges as $ch):
          $solves   = $counts[$ch['id']] ?? 0;
          $hint_on  = (int)($ch['hint_enabled'] ?? 0) === 1;
        ?>
        <tr id="ch-row-<?= $ch['id'] ?>">
          <td style="font-family:var(--fm);color:var(--txt2);">
            <?= str_pad($ch['id'],2,'0',STR_PAD_LEFT) ?>
          </td>
          <td style="font-weight:600;"><?= e($ch['title']) ?></td>
          <td style="font-size:12px;color:var(--txt2);"><?= e($ch['topic']) ?></td>
          <td><?= diff_badge($ch['difficulty']) ?></td>
          <td style="font-family:var(--fm);color:var(--blue);font-weight:600;">
            <?= $ch['points'] ?>
          </td>
          <td>
            <?= $solves > 0
              ? '<span class="badge badge-green">'.$solves.' solve'.($solves>1?'s':'').'</span>'
              : '<span style="color:var(--txt3);">0</span>' ?>
          </td>

          <!-- ── Hint toggle cell ─────────────────────── -->
          <td>
            <button
              class="hint-toggle-btn <?= $hint_on ? 'hint-on' : 'hint-off' ?>"
              id="hint-btn-<?= $ch['id'] ?>"
              onclick="adminToggleHint(<?= $ch['id'] ?>, this)"
              title="<?= $hint_on ? 'Click to lock hint' : 'Click to unlock hint' ?>">
              <?= $hint_on ? '🔓 Unlocked' : '🔒 Locked' ?>
            </button>
          </td>

          <td style="font-family:var(--fm);font-size:12px;color:var(--green);">
            <?= e($ch['flag']) ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<script>
const CSRF_TOKEN = '<?= csrf_token() ?>';
const BASE_URL   = '<?= BASE_URL ?>';

function adminToggleHint(challengeId, btn) {
  btn.disabled = true;
  btn.textContent = '…';

  fetch(BASE_URL + '/pages/admin/toggle_hint.php', {
    method : 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body   : 'challenge_id=' + encodeURIComponent(challengeId)
           + '&csrf='         + encodeURIComponent(CSRF_TOKEN),
  })
  .then(r => r.json())
  .then(data => {
    if (data.error) {
      alert('Error: ' + data.error);
      btn.disabled = false;
      return;
    }
    const on = data.hint_enabled === 1;
    btn.className = 'hint-toggle-btn ' + (on ? 'hint-on' : 'hint-off');
    btn.textContent = on ? '🔓 Unlocked' : '🔒 Locked';
    btn.title       = on ? 'Click to lock hint' : 'Click to unlock hint';
    btn.disabled    = false;
  })
  .catch(() => {
    alert('Network error — please try again.');
    btn.disabled = false;
    location.reload();
  });
}
</script>
<?php html_foot(); ?>
