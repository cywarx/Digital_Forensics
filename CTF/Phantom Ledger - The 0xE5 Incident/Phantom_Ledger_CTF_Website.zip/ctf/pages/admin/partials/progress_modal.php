<!-- Student Progress Modal — included by admin pages -->
<div class="modal-bg" id="modal-progress">
  <div class="modal modal-wide">
    <div class="modal-head">
      <h3>Student Progress</h3>
      <button class="modal-close" onclick="closeModal('progress')">✕</button>
    </div>
    <div id="progress-body" style="min-height:120px;">
      <div style="text-align:center;padding:40px;color:var(--txt2);">Loading…</div>
    </div>
  </div>
</div>
