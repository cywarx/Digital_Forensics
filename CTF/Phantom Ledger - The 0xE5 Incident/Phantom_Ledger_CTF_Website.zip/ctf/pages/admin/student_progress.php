<?php
// AJAX endpoint — returns HTML fragment for the student progress modal.
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/challenges.php';
require_once __DIR__ . '/../../includes/layout.php';

$admin = current_user();
if (!$admin || $admin['role'] !== 'admin') {
    echo '<div style="color:var(--red);padding:20px;">Access denied.</div>'; exit;
}

$uid  = (int)($_GET['id'] ?? 0);
$st   = db()->prepare('SELECT * FROM users WHERE id=? AND role="student"');
$st->execute([$uid]);
$student = $st->fetch();

if (!$student) {
    echo '<div style="color:var(--red);padding:20px;">Student not found.</div>'; exit;
}

$progress   = student_progress($uid);
$earnedPts  = 0;
$solvedCount= 0;
$wrongTotal = 0;
foreach ($progress as $r) {
    if ($r['solved']) {
        $earnedPts += $r['challenge']['points'];
        $solvedCount++;
    }
    $wrongTotal += $r['wrong_tries'];
}
$totalPts = total_pts();
$allCount = count($progress);
$pending  = $allCount - $solvedCount;
$pct      = $allCount > 0 ? round($solvedCount / $allCount * 100) : 0;
?>

<!-- Hero -->
<div class="sp-hero">
  <div class="sp-av"><?= initials($student['full_name']) ?></div>
  <div class="sp-hero-info">
    <h3><?= e($student['full_name']) ?></h3>
    <span>@<?= e($student['username']) ?> &nbsp;·&nbsp; Joined <?= fmt_dt($student['joined_at']) ?></span>
  </div>
</div>

<!-- Stat chips -->
<div class="sp-chips">
  <div class="sp-chip">
    <span class="sp-chip-v" style="color:var(--green);"><?= $solvedCount ?></span>
    <span class="sp-chip-l">Solved</span>
  </div>
  <div class="sp-chip">
    <span class="sp-chip-v" style="color:var(--txt2);"><?= $pending ?></span>
    <span class="sp-chip-l">Pending</span>
  </div>
  <div class="sp-chip">
    <span class="sp-chip-v" style="color:var(--blue);"><?= $earnedPts ?></span>
    <span class="sp-chip-l">Points</span>
  </div>
  <div class="sp-chip">
    <span class="sp-chip-v" style="color:var(--amber);"><?= $totalPts - $earnedPts ?></span>
    <span class="sp-chip-l">Remaining</span>
  </div>
  <div class="sp-chip">
    <span class="sp-chip-v" style="color:var(--red);"><?= $wrongTotal ?></span>
    <span class="sp-chip-l">Wrong Tries</span>
  </div>
</div>

<!-- Overall progress bar -->
<div class="sp-prog-row">
  <span style="font-size:12px;color:var(--txt2);white-space:nowrap;">Overall progress</span>
  <div class="prog-wrap" style="flex:1;margin:0 10px;">
    <div class="prog-bar" style="width:<?= $pct ?>%"></div>
  </div>
  <span style="font-family:var(--fm);font-size:12px;font-weight:600;color:var(--blue);min-width:34px;text-align:right;">
    <?= $pct ?>%
  </span>
</div>

<!-- Per-challenge rows -->
<div class="sp-ch-list">
<?php foreach ($progress as $r):
  $ch     = $r['challenge'];
  $solved = $r['solved'];
  $diff   = DIFF_META[$ch['difficulty']] ?? DIFF_META['EASY'];
?>
  <div class="sp-ch-row <?= $solved ? 'ok' : 'pending' ?>">

    <!-- Bubble -->
    <div class="sp-bubble <?= $solved ? 'ok' : 'pending' ?>">
      <?= $solved ? '✓' : str_pad($ch['id'],2,'0',STR_PAD_LEFT) ?>
    </div>

    <!-- Title + diff badge -->
    <div>
      <div class="sp-ch-title"><?= e($ch['title']) ?></div>
      <div style="display:flex;align-items:center;gap:6px;margin-top:2px;">
        <span class="badge <?= e($diff['cls']) ?>" style="font-size:9px;"><?= e($diff['label']) ?></span>
        <span class="sp-ch-topic"><?= e($ch['topic']) ?></span>
      </div>
    </div>

    <!-- Wrong attempts badge -->
    <div style="text-align:center;">
      <?php if ($r['wrong_tries'] > 0): ?>
        <span class="sp-wrong"><?= $r['wrong_tries'] ?> wrong</span>
      <?php else: ?>
        <span style="font-size:11px;color:var(--txt3);">—</span>
      <?php endif; ?>
    </div>

    <!-- Points + solve time -->
    <div class="sp-time">
      <?php if ($solved): ?>
        <span style="color:var(--green);font-weight:700;font-size:12px;">
          +<?= $ch['points'] ?> pts
        </span><br>
        <?= fmt_dt($r['solved_at']) ?>
      <?php else: ?>
        <span style="color:var(--txt3);"><?= $ch['points'] ?> pts available</span><br>
        <span style="color:var(--txt3);">Not solved yet</span>
      <?php endif; ?>
    </div>

  </div>
<?php endforeach; ?>
</div>
