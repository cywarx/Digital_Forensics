<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/challenges.php';
require_once __DIR__ . '/../includes/layout.php';

$user       = require_student();
$challenges = get_challenges();
$solvedIds  = solved_ids((int)$user['id']);
$solvedSet  = array_flip($solvedIds);
$myPts      = user_pts((int)$user['id']);
$myRank     = user_rank((int)$user['id']);
$totalPts   = total_pts();
$imageName  = get_setting('image_filename', 'ctf1.img');
$imageHash  = get_setting('image_sha256', '');

html_head('Challenges');
top_nav($user, 'challenges');
?>

<div class="page">

  <!-- Image verification banner -->
  <?php if ($imageHash && $imageHash !== 'Run sha256sum ctf1.img and paste the hash here via Admin › Settings'): ?>
  <div class="img-info">
    <div class="img-info-icon">🖼️</div>
    <div class="img-info-body">
      <h4>Evidence Image — <?= e($imageName) ?></h4>
      <p>Before starting, verify your image matches the canonical hash:<br>
         <code>sha256sum <?= e($imageName) ?></code><br>
         Expected: <code><?= e($imageHash) ?></code></p>
    </div>
  </div>
  <?php endif; ?>

  <!-- Stats row -->
  <div class="stat-grid">
    <div class="stat-card" style="--c:var(--blue)">
      <div class="stat-val"><?= $myPts ?></div>
      <div class="stat-lbl">Points Earned</div>
    </div>
    <div class="stat-card" style="--c:var(--green)">
      <div class="stat-val"><?= count($solvedIds) ?></div>
      <div class="stat-lbl">Challenges Solved</div>
    </div>
    <div class="stat-card" style="--c:var(--amber)">
      <div class="stat-val"><?= count($challenges) ?></div>
      <div class="stat-lbl">Total Challenges</div>
    </div>
    <div class="stat-card" style="--c:var(--purple)">
      <div class="stat-val">#<?= $myRank ?: '—' ?></div>
      <div class="stat-lbl">Current Rank</div>
    </div>
  </div>

  <!-- Challenge grid -->
  <div class="page-header">
    <h2>All Challenges</h2>
    <span style="font-size:12px;color:var(--txt2);">
      <?= count($solvedIds) ?> / <?= count($challenges) ?> solved
    </span>
  </div>

  <div class="ch-grid">
  <?php foreach ($challenges as $ch):
    $solved = isset($solvedSet[$ch['id']]);
    $diff   = DIFF_META[$ch['difficulty']] ?? DIFF_META['EASY'];
  ?>
    <div class="ch-card <?= $solved ? 'solved' : '' ?>"
         id="ch-card-<?= $ch['id'] ?>"
         onclick="openChallenge(<?= $ch['id'] ?>);loadChallenge(<?= $ch['id'] ?>)">
      <?php if ($solved): ?>
        <div class="ch-solved-mark">✓ SOLVED</div>
      <?php endif; ?>
      <div class="ch-stripe" style="background:<?= e($ch['accent']) ?>"></div>
      <div class="ch-body">
        <div class="ch-meta">
          <span class="ch-num">CH-<?= str_pad($ch['id'],2,'0',STR_PAD_LEFT) ?></span>
          <span class="badge <?= e($diff['cls']) ?>"><?= e($diff['label']) ?></span>
          <span class="ch-pts" style="color:<?= e($ch['accent']) ?>"><?= $ch['points'] ?> pts</span>
        </div>
        <div class="ch-title"><?= e($ch['title']) ?></div>
        <div class="ch-topic"><?= e($ch['topic']) ?></div>
        <div class="ch-desc"><?= e($ch['real_case']) ?></div>
        <div class="ch-tags">
          <?php foreach (explode(',', $ch['tags']) as $tag): ?>
            <span class="ch-tag"><?= e(trim($tag)) ?></span>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
  </div>

</div><!-- /page -->

<!-- ── Challenge Detail Modal ───────────────────────── -->
<div class="modal-bg" id="modal-challenge">
  <div class="modal modal-wide">
    <div id="modal-ch-stripe" style="height:4px;border-radius:14px 14px 0 0;"></div>
    <div class="modal-head">
      <div>
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;">
          <span id="modal-badge"></span>
          <span style="font-family:var(--fm);font-size:11px;color:var(--txt2);" id="modal-pts"></span>
        </div>
        <h3 id="modal-title">—</h3>
        <div style="font-family:var(--fm);font-size:10px;color:var(--txt2);margin-top:2px;" id="modal-topic"></div>
      </div>
      <button class="modal-close" onclick="closeModal('challenge')">✕</button>
    </div>
    <div class="modal-body" id="modal-ch-body">
      <div style="text-align:center;padding:20px;color:var(--txt2);">Loading…</div>
    </div>
  </div>
</div>

<script>
const BASE_URL   = '<?= BASE_URL ?>';
const CSRF_TOKEN = '<?= csrf_token() ?>';

function loadChallenge(id) {
  fetch(BASE_URL + '/pages/get_challenge.php?id=' + id)
    .then(r => r.json())
    .then(data => {
      if (!data.ch) return;
      const ch = data.ch;
      document.getElementById('modal-ch-stripe').style.background = ch.accent;
      document.getElementById('modal-badge').innerHTML  = ch.diff_badge;
      document.getElementById('modal-pts').textContent  = ch.points + ' points';
      document.getElementById('modal-title').textContent= ch.title;
      document.getElementById('modal-topic').textContent= ch.topic;

      let html = '';
      // Real case
      html += '<div><div class="ch-section-lbl">Real World Case</div>'
            + '<div class="ch-case-box">' + escHtml(ch.real_case) + '</div></div>';
      // Story
      html += '<div><div class="ch-section-lbl">Scenario</div>'
            + '<div class="ch-story">' + ch.story + '</div></div>';
      // Hint — shown only when admin has unlocked this specific challenge
      html += '<div><div class="ch-section-lbl">Think About This</div>';
      if (data.hint_enabled && ch.hint) {
        html += '<div class="ch-hint-box">'
              + '<div class="ch-hint-lbl">💡 Methodology Hint</div>'
              + '<div>' + ch.hint + '</div>'
              + '</div>';
      } else {
        html += '<div class="ch-hint-locked">'
              + '<span class="ch-hint-lock-icon">🔒</span>'
              + '<span>Hint is <strong>locked</strong> for this challenge.<br>'
              + 'Your instructor can unlock it from the Admin panel.</span>'
              + '</div>';
      }
      html += '</div>';
      // Flag submit
      if (data.solved) {
        html += '<div class="alert success">🎉 You already solved this challenge!</div>';
      } else {
        html += '<div style="background:var(--raised);border-radius:var(--rsm);padding:13px 15px;">'
              + '<div class="ch-section-lbl">Submit Flag</div>'
              + '<div id="flag-msg" class="msg"></div>'
              + '<div class="flag-row" style="margin-top:8px;">'
              + '<input type="text" id="flag-input" placeholder="Cywarx{your_flag_here}" autocomplete="off" spellcheck="false" class="field input">'
              + '<button class="btn btn-green" id="flag-btn" onclick="submitFlag()">Submit</button>'
              + '</div></div>';
      }

      document.getElementById('modal-ch-body').innerHTML = html;
      if (!data.solved) {
        const inp = document.getElementById('flag-input');
        if (inp) setTimeout(() => inp.focus(), 150);
        inp.addEventListener('keydown', e => { if(e.key==='Enter') submitFlag(); });
      }
    });
}

function escHtml(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
</script>

<?php html_foot(); ?>
