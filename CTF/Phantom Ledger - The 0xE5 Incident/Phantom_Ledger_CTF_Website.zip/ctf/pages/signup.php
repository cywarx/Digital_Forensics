<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';

redirect_if_logged_in();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_ok()) {
        $error = 'Invalid request. Please try again.';
    } elseif (($_POST['password'] ?? '') !== ($_POST['confirm'] ?? '')) {
        $error = 'Passwords do not match.';
    } else {
        $res = attempt_register(
            $_POST['full_name'] ?? '',
            $_POST['username']  ?? '',
            $_POST['password']  ?? ''
        );
        if ($res['ok']) {
            header('Location: ' . BASE_URL . '/pages/dashboard.php'); exit;
        }
        $error = $res['error'];
    }
}
auth_head('Sign Up');
?>
<div class="auth-wrap">
  <div class="auth-box">
    <div class="auth-logo-wrap">
      <div class="auth-logo">CY<span>WARX</span></div>
      <div class="auth-tagline">Digital Forensics CTF</div>
    </div>
    <form class="auth-form" method="POST">
      <?= csrf_field() ?>
      <h3 style="font-size:15px;color:var(--txt2);font-weight:500;">Create your account</h3>
      <?php if ($error): ?>
        <div class="alert error"><?= e($error) ?></div>
      <?php endif; ?>
      <div class="field">
        <label>Full Name</label>
        <input type="text" name="full_name" placeholder="e.g. Priya Sharma"
               value="<?= e($_POST['full_name'] ?? '') ?>" autocomplete="name" required>
      </div>
      <div class="field">
        <label>Username</label>
        <input type="text" name="username" placeholder="Letters, numbers, underscores (min 3)"
               value="<?= e($_POST['username'] ?? '') ?>" autocomplete="username" required>
        <span class="field-hint">This is what you use to log in.</span>
      </div>
      <div class="field">
        <label>Password</label>
        <input type="password" name="password" placeholder="Min 6 characters"
               autocomplete="new-password" required>
      </div>
      <div class="field">
        <label>Confirm Password</label>
        <input type="password" name="confirm" placeholder="Repeat your password"
               autocomplete="new-password" required>
      </div>
      <button type="submit" class="btn btn-green btn-block">Create Account</button>
    </form>
    <div class="auth-footer">
      Already have an account? <a href="<?= BASE_URL ?>/pages/login.php">Sign in here</a>
    </div>
  </div>
</div>
<?php auth_foot(); ?>
