<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/challenges.php';
require_once __DIR__ . '/../includes/layout.php';

$user       = require_student();
$uid        = (int)$user['id'];
$myPts      = user_pts($uid);
$solvedIds  = solved_ids($uid);
$allCh      = get_challenges();
$totalPts   = total_pts();
$rank       = user_rank($uid);
$progress   = student_progress($uid);

html_head('Profile');
top_nav($user, 'profile');
?>
<div class="page">
  <div class="page-header"><h2>My Profile</h2></div>

  <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px;">

    <!-- Account info -->
    <div class="card">
      <div class="card-head"><h3>Account Info</h3></div>
      <div class="card-body" style="display:flex;flex-direction:column;gap:12px;">
        <div>
          <div style="font-size:11px;color:var(--txt2);margin-bottom:2px;">Full Name</div>
          <div style="font-weight:600;"><?= e($user['full_name']) ?></div>
        </div>
        <div>
          <div style="font-size:11px;color:var(--txt2);margin-bottom:2px;">Username</div>
          <div style="font-family:var(--fm);font-size:13px;">@<?= e($user['username']) ?></div>
        </div>
        <div>
          <div style="font-size:11px;color:var(--txt2);margin-bottom:2px;">Rank</div>
          <div style="font-family:var(--fm);font-size:18px;font-weight:800;color:var(--blue);">#<?= $rank ?: '—' ?></div>
        </div>
      </div>
    </div>

    <!-- Progress -->
    <div class="card">
      <div class="card-head"><h3>Progress</h3></div>
      <div class="card-body" style="display:flex;flex-direction:column;gap:14px;">
        <div>
          <div style="display:flex;justify-content:space-between;font-size:12px;color:var(--txt2);margin-bottom:6px;">
            <span>Challenges solved</span>
            <span><?= count($solvedIds) ?> / <?= count($allCh) ?></span>
          </div>
          <?= progress_bar(count($solvedIds), count($allCh)) ?>
        </div>
        <div>
          <div style="display:flex;justify-content:space-between;font-size:12px;color:var(--txt2);margin-bottom:6px;">
            <span>Points earned</span>
            <span><?= $myPts ?> / <?= $totalPts ?></span>
          </div>
          <?= progress_bar($myPts, $totalPts, 'var(--green)') ?>
        </div>
      </div>
    </div>

  </div>

  <!-- Per-challenge breakdown -->
  <div class="card">
    <div class="card-head"><h3>Challenge Breakdown</h3></div>
    <div class="card-body-p0">
      <?php foreach ($progress as $row):
        $ch     = $row['challenge'];
        $diff   = DIFF_META[$ch['difficulty']] ?? DIFF_META['EASY'];
        $solved = $row['solved'];
      ?>
      <div style="display:grid;grid-template-columns:30px 1fr auto 120px;
                  align-items:center;gap:10px;padding:10px 16px;
                  border-bottom:1px solid var(--border);
                  background:<?= $solved ? 'var(--green-bg)' : '' ?>;">

        <!-- Bubble -->
        <div style="width:28px;height:28px;border-radius:50%;
                    display:flex;align-items:center;justify-content:center;
                    font-family:var(--fm);font-size:<?= $solved?'13':'11' ?>px;font-weight:600;
                    background:<?= $solved?'var(--green)':'var(--raised)' ?>;
                    color:<?= $solved?'#0d1117':'var(--txt3)' ?>;
                    border:<?= $solved?'none':'1px solid var(--border)' ?>;">
          <?= $solved ? '✓' : str_pad($ch['id'],2,'0',STR_PAD_LEFT) ?>
        </div>

        <!-- Title + badge -->
        <div>
          <div style="font-size:13px;font-weight:600;"><?= e($ch['title']) ?></div>
          <div style="display:flex;align-items:center;gap:6px;margin-top:2px;">
            <?= diff_badge($ch['difficulty']) ?>
            <span style="font-family:var(--fm);font-size:10px;color:var(--txt2);"><?= e($ch['topic']) ?></span>
          </div>
        </div>

        <!-- Wrong attempts -->
        <div style="text-align:center;">
          <?php if ($row['wrong_tries'] > 0): ?>
            <span style="font-family:var(--fm);font-size:10px;padding:1px 7px;border-radius:4px;
                         background:var(--amber-bg);border:1px solid var(--amber-br);color:var(--amber);">
              <?= $row['wrong_tries'] ?> wrong
            </span>
          <?php else: ?>
            <span style="color:var(--txt3);font-size:11px;">—</span>
          <?php endif; ?>
        </div>

        <!-- Points + time -->
        <div style="font-family:var(--fm);font-size:10px;color:var(--txt2);text-align:right;line-height:1.7;">
          <?php if ($solved): ?>
            <span style="color:var(--green);font-weight:700;font-size:12px;">+<?= $ch['points'] ?> pts</span><br>
            <?= fmt_dt($row['solved_at']) ?>
          <?php else: ?>
            <span style="color:var(--txt3);"><?= $ch['points'] ?> pts available</span><br>
            <span style="color:var(--txt3);">Not solved yet</span>
          <?php endif; ?>
        </div>

      </div>
      <?php endforeach; ?>
    </div>
  </div>

</div>
<?php html_foot(); ?>
