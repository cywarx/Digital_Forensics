<?php
// ==========================================================
//  CYWARX CTF — Auth & Session Helpers
// ==========================================================
require_once __DIR__ . '/config.php';

// Start session once
if (session_status() === PHP_SESSION_NONE) {
    session_name(SESSION_NAME);
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'secure'   => false,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

// ----------------------------------------------------------
//  Return current logged-in user row, or null
// ----------------------------------------------------------
function current_user(): ?array {
    if (empty($_SESSION['uid'])) return null;
    static $cache = null;
    if ($cache && $cache['id'] == $_SESSION['uid']) return $cache;
    $st = db()->prepare('SELECT id,full_name,username,role FROM users WHERE id=?');
    $st->execute([$_SESSION['uid']]);
    $cache = $st->fetch() ?: null;
    return $cache;
}

// ----------------------------------------------------------
//  Route guards
// ----------------------------------------------------------
function require_login(): array {
    $u = current_user();
    if (!$u) { header('Location:'.BASE_URL.'/pages/login.php'); exit; }
    return $u;
}

function require_student(): array {
    $u = require_login();
    if ($u['role'] === 'admin') { header('Location:'.BASE_URL.'/pages/admin/index.php'); exit; }
    return $u;
}

function require_admin(): array {
    $u = require_login();
    if ($u['role'] !== 'admin') { header('Location:'.BASE_URL.'/pages/dashboard.php'); exit; }
    return $u;
}

function redirect_if_logged_in(): void {
    $u = current_user();
    if (!$u) return;
    if ($u['role'] === 'admin') { header('Location:'.BASE_URL.'/pages/admin/index.php'); exit; }
    header('Location:'.BASE_URL.'/pages/dashboard.php'); exit;
}

// ----------------------------------------------------------
//  Login
// ----------------------------------------------------------
function attempt_login(string $username, string $password): array {
    $st = db()->prepare('SELECT * FROM users WHERE username=? LIMIT 1');
    $st->execute([strtolower(trim($username))]);
    $u = $st->fetch();
    if (!$u)
        return ['ok'=>false,'error'=>'No account found with that username.'];
    if (!password_verify($password, $u['password']))
        return ['ok'=>false,'error'=>'Incorrect password.'];
    session_regenerate_id(true);
    $_SESSION['uid'] = $u['id'];
    return ['ok'=>true,'user'=>$u];
}

// ----------------------------------------------------------
//  Register
// ----------------------------------------------------------
function attempt_register(string $fullName, string $username, string $password): array {
    $fullName = trim($fullName);
    $username = strtolower(trim($username));

    if (!$fullName || !$username || !$password)
        return ['ok'=>false,'error'=>'All fields are required.'];
    if (mb_strlen($username) < 3)
        return ['ok'=>false,'error'=>'Username must be at least 3 characters.'];
    if (!preg_match('/^[a-z0-9_]+$/', $username))
        return ['ok'=>false,'error'=>'Username: letters, numbers and underscores only.'];
    if (mb_strlen($password) < 6)
        return ['ok'=>false,'error'=>'Password must be at least 6 characters.'];

    $st = db()->prepare('SELECT id FROM users WHERE username=?');
    $st->execute([$username]);
    if ($st->fetch())
        return ['ok'=>false,'error'=>'Username already taken. Choose another.'];

    $hash = password_hash($password, PASSWORD_BCRYPT, ['cost'=>12]);
    $st   = db()->prepare(
        'INSERT INTO users (full_name,username,password,role) VALUES (?,?,?,"student")'
    );
    $st->execute([$fullName, $username, $hash]);
    $id = (int)db()->lastInsertId();

    session_regenerate_id(true);
    $_SESSION['uid'] = $id;
    return ['ok'=>true,'user'=>['id'=>$id,'full_name'=>$fullName,'username'=>$username,'role'=>'student']];
}

// ----------------------------------------------------------
//  Logout
// ----------------------------------------------------------
function logout(): void {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(),'',time()-42000,$p['path'],$p['domain'],$p['secure'],$p['httponly']);
    }
    session_destroy();
    header('Location:'.BASE_URL.'/pages/login.php'); exit;
}

// ----------------------------------------------------------
//  CSRF
// ----------------------------------------------------------
function csrf_token(): string {
    if (empty($_SESSION['csrf']))
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function csrf_field(): string {
    return '<input type="hidden" name="csrf" value="'.csrf_token().'">';
}
function csrf_ok(): bool {
    return hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '');
}

// ----------------------------------------------------------
//  Flash messages
// ----------------------------------------------------------
function flash_set(string $key, string $msg, string $type='error'): void {
    $_SESSION['flash'][$key] = ['msg'=>$msg,'type'=>$type];
}
function flash_get(string $key): ?array {
    if (!isset($_SESSION['flash'][$key])) return null;
    $f = $_SESSION['flash'][$key];
    unset($_SESSION['flash'][$key]);
    return $f;
}
function flash_html(string $key): string {
    $f = flash_get($key);
    if (!$f) return '';
    return '<div class="alert '.e($f['type']).'">'.e($f['msg']).'</div>';
}
