<?php
// ==========================================================
//  cywarx CTF — Configuration
//  Edit DB_USER and DB_PASS to match your MySQL setup.
//  Everything else can stay as-is for XAMPP/WAMP defaults.
// ==========================================================

// --- Database ---
define('DB_HOST',    'localhost');
define('DB_NAME',    'cywarx_ctf');
define('DB_USER',    'root');      // your MySQL username
define('DB_PASS',    'Warrior@007');          // your MySQL password (blank for XAMPP default)
define('DB_CHARSET', 'utf8mb4');

// --- App branding ---
define('APP_NAME',    'CYWARX');
define('APP_TAGLINE', 'Digital Forensics CTF');

// --- Session ---
define('SESSION_NAME', 'cywarx_sess');

// --- Base URL (leave blank if running at http://localhost/cywarx) ---
// Example: if your folder is htdocs/cywarx, BASE_URL = '/cywarx'
define('BASE_URL', '');

// ==========================================================
//  DB connection — returns singleton PDO
// ==========================================================
function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset='.DB_CHARSET;
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            die('
<style>body{font-family:monospace;background:#0d1117;color:#f85149;padding:40px;}
.box{border:1px solid #f85149;padding:20px;border-radius:8px;max-width:600px;}</style>
<div class="box">
<h2>Database connection failed</h2>
<p>Check <code>DB_HOST</code>, <code>DB_USER</code>, <code>DB_PASS</code>
   in <code>includes/config.php</code></p>
<p>Have you run the installer at <code>/cywarx/install/</code> ?</p>
<pre>'.htmlspecialchars($e->getMessage()).'</pre>
</div>');
        }
    }
    return $pdo;
}

// ==========================================================
//  Shared helper: safe HTML output
// ==========================================================
function e(?string $s): string {
    return htmlspecialchars((string)($s ?? ''), ENT_QUOTES, 'UTF-8');
}
