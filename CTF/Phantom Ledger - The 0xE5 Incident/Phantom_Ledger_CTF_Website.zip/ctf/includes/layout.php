<?php
// ==========================================================
//  CYWARX CTF — Layout Partials
// ==========================================================

function html_head(string $title): void { ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title><?=e($title)?> — CYWARX CTF</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600&family=Outfit:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?=BASE_URL?>/assets/css/style.css">
</head>
<body>
<?php }

// cywarx
// Top nav (shared by student + admin pages)
function top_nav(array $user, string $active=''): void {
    $admin = $user['role']==='admin'; ?>
<nav class="topnav">
  <?php if($admin): ?>
    <span class="topnav-brand" style="color:var(--amber);">
      CY<span style="color:var(--amber);">WARX</span>
      <span class="admin-tag">ADMIN</span>
    </span>
    <?php nav_link('Overview',   BASE_URL.'/pages/admin/index.php',      $active==='overview'); ?>
    <?php nav_link('Students',   BASE_URL.'/pages/admin/students.php',   $active==='students'); ?>
    <?php nav_link('Scoreboard', BASE_URL.'/pages/admin/scoreboard.php', $active==='scoreboard'); ?>
    <?php nav_link('Challenges', BASE_URL.'/pages/admin/challenges.php', $active==='challenges'); ?>
    <?php nav_link('Settings',   BASE_URL.'/pages/admin/settings.php',   $active==='settings'); ?>
  <?php else: ?>
    <a class="topnav-brand" href="<?=BASE_URL?>/pages/dashboard.php">
      CY<span>WARX</span>
    </a>
    <?php nav_link('Challenges',  BASE_URL.'/pages/dashboard.php',    $active==='challenges'); ?>
    <?php nav_link('Leaderboard', BASE_URL.'/pages/leaderboard.php',  $active==='leaderboard'); ?>
    <?php nav_link('Profile',     BASE_URL.'/pages/profile.php',      $active==='profile'); ?>
  <?php endif; ?>

  <div class="topnav-right">
    <span class="topnav-user"><?=e($user['full_name'])?></span>
    <?php if(!$admin): ?>
      <span class="topnav-score" id="nav-score">
        <?=user_pts((int)$user['id'])?> pts
      </span>
    <?php endif; ?>
    <a href="<?=BASE_URL?>/pages/logout.php" class="btn btn-outline btn-sm">Sign Out</a>
  </div>
</nav>
<?php }

function nav_link(string $label, string $href, bool $active): void {
    $cls = $active ? 'topnav-link active' : 'topnav-link';
    echo '<a href="'.e($href).'" class="'.e($cls).'">'.e($label).'</a>';
}

// cywarx
// Page footer
function html_foot(): void { ?>
<script src="<?=BASE_URL?>/assets/js/app.js"></script>
</body>
</html>
<?php }

// cywarx
// Auth page wrapper
function auth_head(string $title): void { html_head($title); }
function auth_foot(): void { html_foot(); }

// cywarx
// Modal helper — renders a hidden modal div
function modal(string $id, string $title, callable $body, string $foot=''): void { ?>
<div class="modal-bg" id="modal-<?=e($id)?>">
  <div class="modal">
    <div class="modal-head">
      <h3><?=e($title)?></h3>
      <button class="modal-close" onclick="closeModal('<?=e($id)?>')">✕</button>
    </div>
    <div class="modal-body"><?php $body(); ?></div>
    <?php if($foot): ?><div class="modal-foot"><?=$foot?></div><?php endif; ?>
  </div>
</div>
<?php }

// cywarx
// Diff badge HTML
function diff_badge(string $diff): string {
    $m = DIFF_META[$diff] ?? DIFF_META['EASY'];
    return '<span class="badge '.e($m['cls']).'">'.e($m['label']).'</span>';
}

// cywarx
// Format datetime nicely
function fmt_dt(?string $dt): string {
    if (!$dt) return '—';
    return date('d M Y, H:i', strtotime($dt));
}

// cywarx
// Initials from full name
function initials(string $name): string {
    $words = preg_split('/\s+/', trim($name));
    $out   = '';
    foreach ($words as $w) $out .= strtoupper(mb_substr($w,0,1));
    return mb_substr($out,0,2);
}

// cywarx
// Inline alert from PHP value
function alert_html(string $msg, string $type='error'): string {
    if (!$msg) return '';
    return '<div class="alert '.e($type).'">'.e($msg).'</div>';
}

// cywarx
// Progress bar HTML
function progress_bar(int $val, int $max, string $color='var(--blue)'): string {
    $pct = $max > 0 ? min(100, round($val/$max*100)) : 0;
    return '<div class="prog-wrap"><div class="prog-bar" style="width:'.$pct.'%;background:'.$color.'"></div></div>';
}