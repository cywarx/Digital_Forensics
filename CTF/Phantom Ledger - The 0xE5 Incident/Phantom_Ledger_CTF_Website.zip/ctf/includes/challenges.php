<?php
// ==========================================================
//  CYWARX CTF — Challenge & Score Helpers
// ==========================================================
require_once __DIR__ . '/config.php';

// Difficulty → badge CSS class + label
const DIFF_META = [
    'EASY'     => ['cls'=>'badge-green', 'label'=>'Easy'],
    'EASY-MED' => ['cls'=>'badge-amber', 'label'=>'Easy-Med'],
    'MEDIUM'   => ['cls'=>'badge-blue',  'label'=>'Medium'],
    'MED-HARD' => ['cls'=>'badge-orange','label'=>'Med-Hard'],
    'HARD'     => ['cls'=>'badge-red',   'label'=>'Hard'],
    'EXPERT'   => ['cls'=>'badge-purple','label'=>'Expert'],
];

// ----------------------------------------------------------
//  Get all active challenges
// ----------------------------------------------------------
function get_challenges(): array {
    return db()->query(
        'SELECT * FROM challenges WHERE active=1 ORDER BY sort_order ASC'
    )->fetchAll();
}

// ----------------------------------------------------------
//  Get one challenge
// ----------------------------------------------------------
function get_challenge(int $id): ?array {
    $st = db()->prepare('SELECT * FROM challenges WHERE id=? AND active=1');
    $st->execute([$id]);
    return $st->fetch() ?: null;
}

// ----------------------------------------------------------
//  IDs of challenges solved by a user  → [id, id, ...]
// ----------------------------------------------------------
function solved_ids(int $userId): array {
    $st = db()->prepare(
        'SELECT challenge_id FROM submissions WHERE user_id=? AND is_correct=1'
    );
    $st->execute([$userId]);
    return array_column($st->fetchAll(), 'challenge_id');
}

// ----------------------------------------------------------
//  Points earned by a user
// ----------------------------------------------------------
function user_pts(int $userId): int {
    $st = db()->prepare(
        'SELECT COALESCE(SUM(c.points),0)
         FROM submissions s
         JOIN challenges c ON c.id=s.challenge_id
         WHERE s.user_id=? AND s.is_correct=1'
    );
    $st->execute([$userId]);
    return (int)$st->fetchColumn();
}

// ----------------------------------------------------------
//  Submit a flag
//  Returns ['ok'=>true,'pts'=>n] or ['ok'=>false,'error'=>'...']
// ----------------------------------------------------------
function submit_flag(int $userId, int $challengeId, string $input): array {
    $ch = get_challenge($challengeId);
    if (!$ch) return ['ok'=>false,'error'=>'Challenge not found.'];

    // Already solved?
    $st = db()->prepare(
        'SELECT id FROM submissions WHERE user_id=? AND challenge_id=? AND is_correct=1'
    );
    $st->execute([$userId,$challengeId]);
    if ($st->fetch())
        return ['ok'=>false,'error'=>'You already solved this challenge!','already'=>true];

    $correct = (strcasecmp(trim($input), trim($ch['flag'])) === 0);

    $st = db()->prepare(
        'INSERT INTO submissions (user_id,challenge_id,flag_input,is_correct) VALUES (?,?,?,?)'
    );
    $st->execute([$userId, $challengeId, trim($input), $correct ? 1 : 0]);

    if ($correct) return ['ok'=>true,'pts'=>(int)$ch['points']];
    return ['ok'=>false,'error'=>'Wrong flag. Keep trying!'];
}

// ----------------------------------------------------------
//  Full scoreboard — sorted by pts desc
// ----------------------------------------------------------
function scoreboard(): array {
    return db()->query(
        "SELECT u.id, u.full_name, u.username, u.joined_at,
                COUNT(s.id) AS solved,
                COALESCE(SUM(c.points),0) AS pts
         FROM users u
         LEFT JOIN submissions s ON s.user_id=u.id AND s.is_correct=1
         LEFT JOIN challenges  c ON c.id=s.challenge_id
         WHERE u.role='student'
         GROUP BY u.id
         ORDER BY pts DESC, u.joined_at ASC"
    )->fetchAll();
}

// ----------------------------------------------------------
//  1-based rank of a single user
// ----------------------------------------------------------
function user_rank(int $userId): int {
    foreach (scoreboard() as $i => $row)
        if ((int)$row['id'] === $userId) return $i + 1;
    return 0;
}

// ----------------------------------------------------------
//  Total possible points
// ----------------------------------------------------------
function total_pts(): int {
    return (int)db()->query(
        'SELECT COALESCE(SUM(points),0) FROM challenges WHERE active=1'
    )->fetchColumn();
}

// ----------------------------------------------------------
//  Per-challenge solve counts (admin)
// ----------------------------------------------------------
function solve_counts(): array {
    $rows = db()->query(
        'SELECT challenge_id, COUNT(*) AS n FROM submissions
         WHERE is_correct=1 GROUP BY challenge_id'
    )->fetchAll();
    $out = [];
    foreach ($rows as $r) $out[(int)$r['challenge_id']] = (int)$r['n'];
    return $out;
}

// ----------------------------------------------------------
//  Detailed per-challenge progress for one student (admin)
// ----------------------------------------------------------
function student_progress(int $userId): array {
    $challenges = get_challenges();
    $st = db()->prepare(
        'SELECT challenge_id, is_correct, submitted_at
         FROM submissions WHERE user_id=? ORDER BY submitted_at ASC'
    );
    $st->execute([$userId]);
    $subs = $st->fetchAll();

    $byCh = [];
    foreach ($subs as $s) $byCh[(int)$s['challenge_id']][] = $s;

    $rows = [];
    foreach ($challenges as $ch) {
        $cid   = (int)$ch['id'];
        $all   = $byCh[$cid] ?? [];
        $ok    = array_filter($all, fn($s)=> $s['is_correct']);
        $wrong = array_filter($all, fn($s)=>!$s['is_correct']);
        $solved= count($ok) > 0;
        $rows[] = [
            'challenge'   => $ch,
            'solved'      => $solved,
            'solved_at'   => $solved ? array_values($ok)[0]['submitted_at'] : null,
            'wrong_tries' => count($wrong),
        ];
    }
    return $rows;
}

// ----------------------------------------------------------
//  Recent N submissions across all users (admin overview)
// ----------------------------------------------------------
function recent_subs(int $n=12): array {
    $st = db()->prepare(
        'SELECT s.*, u.full_name, u.username, c.title AS ch_title
         FROM submissions s
         JOIN users      u ON u.id=s.user_id
         JOIN challenges c ON c.id=s.challenge_id
         ORDER BY s.submitted_at DESC LIMIT ?'
    );
    $st->execute([$n]);
    return $st->fetchAll();
}

// ----------------------------------------------------------
//  Get / set a setting
// ----------------------------------------------------------
function get_setting(string $key, string $default=''): string {
    $st = db()->prepare('SELECT `value` FROM settings WHERE `key`=?');
    $st->execute([$key]);
    $v = $st->fetchColumn();
    return $v !== false ? $v : $default;
}
function set_setting(string $key, string $value): void {
    db()->prepare(
        'INSERT INTO settings (`key`,`value`) VALUES (?,?)
         ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)'
    )->execute([$key,$value]);
}

// ----------------------------------------------------------
//  Per-challenge hint toggle (admin only)
//  Flips hint_enabled for one challenge, returns new state (0 or 1)
// ----------------------------------------------------------
function toggle_challenge_hint(int $id): int {
    db()->prepare(
        'UPDATE challenges SET hint_enabled = 1 - hint_enabled WHERE id = ?'
    )->execute([$id]);
    $st = db()->prepare('SELECT hint_enabled FROM challenges WHERE id = ?');
    $st->execute([$id]);
    return (int)$st->fetchColumn();
}

// ----------------------------------------------------------
//  Set hint visibility explicitly for one challenge
// ----------------------------------------------------------
function set_challenge_hint(int $id, int $enabled): void {
    db()->prepare(
        'UPDATE challenges SET hint_enabled = ? WHERE id = ?'
    )->execute([$enabled ? 1 : 0, $id]);
}
