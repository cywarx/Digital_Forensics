# Local Domain Setup

> **Tags:** #apache #localdev #cywarx
> **Status:** ✅ Working

---

## Step 1 — /etc/hosts

```bash
sudo nano /etc/hosts
```

Add:
```
127.0.0.1    cywarx.ctf
```

---

## Step 2 — Create VirtualHost

```bash
sudo nano /etc/apache2/sites-available/cywarx.conf
```

```apache
<VirtualHost *:80>
    ServerName cywarx.ctf
    DocumentRoot /var/www/html/ctf

    <Directory /var/www/html/ctf>
        AllowOverride All
        Require all granted
    </Directory>
</VirtualHost>
```

---

## Step 3 — Enable & Restart

```bash
sudo a2ensite cywarx.conf
sudo a2enmod rewrite
sudo systemctl restart apache2
```

---

## Step 4 — Fix BASE_URL (if app redirects wrongly)

```bash
sudo nano /var/www/html/ctf/includes/config.php
```

```php
// Change this
define('BASE_URL', '/ctf');

// To this
define('BASE_URL', '');
```

---

> [!note] Access via `http://cywarx.ctf`
