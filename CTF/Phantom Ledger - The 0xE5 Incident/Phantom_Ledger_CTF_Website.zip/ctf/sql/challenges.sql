-- ==========================================================
--  CYWARX CTF — Challenge Seed Data
--  Run after schema.sql
-- ==========================================================
USE cywarx_ctf;

SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE challenges;
SET FOREIGN_KEY_CHECKS = 1;

INSERT INTO challenges
  (title, topic, difficulty, points, accent, real_case, story, hint, tags, flag, sort_order)
VALUES

-- 01
('What Am I Really?',
 'File Signatures & Magic Bytes',
 'EASY', 50, '#58a6ff',
 'Enron — investigators identified renamed malware purely by reading raw hex byte signatures, ignoring the misleading file extension.',
 'Suspect <strong>Rohan Mehta</strong> renamed his keylogger <code>invoice.exe</code> to look like an ordinary file before surrendering the device. It is deleted from the P2 (BACKUP) partition of <code>ctf1.img</code>.<br><br>Recover the deleted file using <strong>The Sleuth Kit</strong>, then run <strong>file</strong> and <strong>xxd</strong> on it. The file extension lies — the first two bytes never do.',
 '<strong>Step 1</strong> — find the deleted file:<br><code>mmls ctf1.img</code> (P2 = sector 133121), then<br><code>fls -r -d -o 133121 ctf1.img</code> (note invoice.exe inode)<br><br><strong>Step 2</strong> — recover it:<br><code>icat -o 133121 ctf1.img &lt;inode&gt; &gt; recovered.bin</code><br><br><strong>Step 3</strong> — identify it:<br><code>file recovered.bin</code> and <code>xxd recovered.bin | head -2</code>. The first two bytes spell the answer.',
 'Magic Bytes,xxd,file,fls,icat,Sleuth Kit',
 'Cywarx{MZ_exe_h1dd3n_4s_txt}', 1),

-- 02
('The Metadata Witness',
 'EXIF Metadata — OS Artifacts',
 'EASY', 75, '#3fb950',
 'Jill Dando murder — EXIF metadata and cell-tower records placed the suspect at the crime scene at the exact time of the murder, destroying his alibi.',
 'Rohan claims he was at home all evening. He posted <code>college_fest.jpg</code> (P1 partition) and <code>fest_2024.jpg</code> (P2/Photos/) online — both silently carry GPS coordinates proving he was in Jaipur city centre at 14:32 on 17 March 2024.<br><br>A secret value is also embedded in the EXIF <code>UserComment</code> field, invisible to any normal viewer. Mount the partition and use <strong>exiftool</strong> to expose it.',
 '<strong>Step 1</strong> — mount P1 (offset = 2048 × 512 = 1,048,576 bytes):<br><code>sudo mount -o loop,offset=1048576 ctf1.img /mnt/p1</code><br><br><strong>Step 2</strong> — read all metadata:<br><code>exiftool /mnt/p1/college_fest.jpg</code><br><br><strong>Step 3</strong> — target the hidden field:<br><code>exiftool -UserComment /mnt/p1/college_fest.jpg</code>',
 'EXIF,GPS,exiftool,mount',
 'Cywarx{3x1f_k1ll5_4n0nym1ty}', 2),

-- 03
('Deleted But Not Gone',
 'FAT32 Deleted File Recovery',
 'EASY-MED', 100, '#d29922',
 'Corporate fraud — 200,000 deleted emails were fully recovered from executive drives, proving deliberate misconduct in court.',
 'Rohan deleted <code>kl.log</code> — his keylogger output — from the FAT32 BACKUP partition of <code>ctf1.img</code> before surrendering the device.<br><br>In FAT32, deletion only marks the directory entry with <code>0xE5</code> — the actual data clusters are never erased. Use <strong>fls</strong> and <strong>icat</strong> to list and recover the file.',
 '<strong>Step 1</strong> — check layout:<br><code>mmls ctf1.img</code> (P2 = sector 133121)<br><br><strong>Step 2</strong> — list deleted files:<br><code>fls -r -d -o 133121 ctf1.img</code> (the <code>*</code> marks deleted — note kl.log inode)<br><br><strong>Step 3</strong> — recover &amp; read:<br><code>icat -o 133121 ctf1.img &lt;inode&gt; &gt; kl.log</code><br><code>cat kl.log</code>',
 'FAT32,fls,icat,mmls,Sleuth Kit',
 'Cywarx{s3ct0r_z3r0_n3v3r_li3s}', 3),

-- 04
('The MFT Never Forgets',
 'NTFS Master File Table & Timestomping',
 'MEDIUM', 150, '#58a6ff',
 'WannaCry (2017) — analysts exposed the true malware install time using $FILE_NAME timestamps that the attackers could not modify without kernel access.',
 'Inside <code>ntfs_evidence.img</code> — a visible file on P2 of <code>ctf1.img</code> — is a deleted <code>keylogger.exe</code> whose <code>$STANDARD_INFORMATION</code> timestamps were faked to <strong>2020-01-01 00:00:00</strong>.<br><br>NTFS stores a second set in <code>$FILE_NAME</code> that requires kernel access to modify. Mount the image and use <strong>istat</strong> to compare both sets and find the real install time.',
 '<strong>Step 1</strong> — mount P2:<br><code>sudo mount -o loop,offset=68157952 ctf1.img /mnt/p2</code><br><br><strong>Step 2</strong> — inspect with istat:<br><code>istat /mnt/p2/ntfs_evidence.img 2</code><br><br><strong>Step 3</strong> — use strings:<br><code>strings /mnt/p2/ntfs_evidence.img | grep -A4 "STANDARD"</code><br><br>When $STANDARD_INFORMATION and $FILE_NAME differ, timestomping occurred. Real creation hour is part of the flag.',
 'NTFS,MFT,istat,strings,Timestomping',
 'Cywarx{t1m3st0mp_09}', 4),

-- 05
('Sector Zero Speaks',
 'Storage Fundamentals — MBR & Disk Structure',
 'MEDIUM', 175, '#bc8cff',
 'Manchester Arena bombing (2017) — investigators recovered communications hidden in raw disk sectors completely invisible to the operating system.',
 'A <strong>13-byte string</strong> has been written at byte offset <code>0x100</code> (decimal 256) inside the MBR bootstrap code region of <code>ctf1.img</code>.<br><br>The MBR occupies the very first 512 bytes of every disk. The 446-byte bootstrap code area is never displayed by any file manager — making it a perfect hiding spot.',
 '<strong>Step 1</strong> — dump the MBR:<br><code>dd if=ctf1.img bs=512 count=1 | xxd</code><br><br><strong>Step 2</strong> — look at offset 0x100 and read the ASCII on the right<br><br><strong>Step 3</strong> — cleaner view:<br><code>xxd -s 256 -l 16 ctf1.img</code><br><br>Convert the 13 hex bytes at offset 256 to ASCII — that is your flag.',
 'MBR,dd,xxd,Disk Structure,Hex',
 'Cywarx{h3dd3n_m4rk3r}', 5),

-- 06
('Quick Format? Think Again.',
 'Formatted Partition Recovery — TestDisk',
 'MED-HARD', 200, '#f0883e',
 'Twitter hack (2020) — suspects quick-formatted drives moments before arrest; forensic teams recovered all data because no cluster data was erased.',
 'Rohan quick-formatted the BACKUP partition in <code>ctf1.img</code> believing all evidence was gone. A quick format only rewrites the <strong>FAT header</strong> (the index map) — the actual data clusters are untouched.<br><br>Use <strong>TestDisk</strong> to rebuild the lost partition table, then mount and read <code>winscp_session.log</code> which contains FTP upload evidence and the flag.',
 '<strong>Step 1</strong> — run TestDisk:<br><code>testdisk ctf1.img</code> → Proceed → None → Analyse → Quick Search → Write<br><br><strong>Step 2</strong> — mount P2 (offset = 133121 × 512 = 68,157,952):<br><code>sudo mount -o loop,offset=68157952 ctf1.img /mnt/p2</code><br><br><strong>Step 3</strong> — read the log:<br><code>cat /mnt/p2/winscp_session.log</code><br>or: <code>strings ctf1.img | grep -i "winscp"</code>',
 'TestDisk,FAT32,strings,Quick Format,Partition Recovery',
 'Cywarx{qu1ck_f0rm4t_15_n0t_w1p3}', 6),

-- 07
('Windows Never Forgets',
 'OS Artifacts — Prefetch & Windows Event Logs',
 'MED-HARD', 225, '#ff7ab2',
 'Enron — Prefetch files proved that executives ran evidence-shredding software multiple times on the very day investigators arrived.',
 'The deleted <code>ram_capture.bin</code> inside <code>ctf1.img</code> (P2 partition) is a simulated Windows artifact dump.<br><br>It records that <code>keylogger.exe</code> was executed <strong>7 times</strong>, and that Security <strong>EventID 1102</strong> fired — the event written when the Security log is deliberately cleared. Use <strong>fls</strong>, <strong>icat</strong>, and <strong>strings</strong> to recover and read this file.',
 '<strong>Step 1</strong> — find the deleted file:<br><code>fls -r -d -o 133121 ctf1.img | grep ram_capture</code><br><br><strong>Step 2</strong> — recover it:<br><code>icat -o 133121 ctf1.img &lt;inode&gt; &gt; ram_capture.bin</code><br><br><strong>Step 3</strong> — search for evidence:<br><code>strings ram_capture.bin | grep -E "Prefetch|EventID|ran|times"</code><br><br>The run count (7) and the EventID that proves log clearing form the flag.',
 'fls,icat,strings,Prefetch,EventID 1102,Windows Artifacts',
 'Cywarx{1102_ran_7_t1m3s}', 7),

-- 08
('Carving the Void',
 'Data Carving — File Signatures on Raw Bytes',
 'HARD', 250, '#f85149',
 'CAID investigations — images were carved from completely formatted drives using file signature matching, with no filesystem present at all.',
 'The entire filesystem on P2 of <code>ctf1.img</code> has been destroyed. No partition table, no FAT, no directory tree — just raw bytes.<br><br>However, JPEG stubs and a ZIP archive are embedded in the raw cluster space. <strong>Foremost</strong> and <strong>Binwalk</strong> need no filesystem — they scan every byte for known magic byte signatures and carve out the files automatically.',
 '<strong>Step 1</strong> — carve with Foremost:<br><code>foremost -t jpg,zip -i ctf1.img -o /tmp/carved/</code><br>then: <code>cat /tmp/carved/audit.txt</code><br><br><strong>Step 2</strong> — alternative (Binwalk):<br><code>binwalk -e ctf1.img --directory=/tmp/binwalk_out/</code><br><br><strong>Step 3</strong> — extract the ZIP and read it:<br><code>unzip /tmp/carved/zip/00000001.zip -d /tmp/evidence/</code><br><code>cat /tmp/evidence/recovered_evidence.txt</code>',
 'Foremost,Binwalk,Data Carving,Magic Bytes,unzip',
 'Cywarx{c4rv1ng_f1nd5_th3_truth}', 8),

-- 09
('RAM Knows Everything',
 'Volatile Data & Memory Forensics',
 'HARD', 300, '#3fb950',
 'WannaCry (2017) — researchers extracted RSA encryption keys directly from live RAM before reboot, creating WanaKiwi which saved thousands of victims.',
 'The deleted <code>ram_capture.bin</code> inside <code>ctf1.img</code> is a simulated Windows memory dump. It holds the full command-line of PID 1337 (<code>keylogger.exe</code>) — including an encryption key passed as a <code>--key</code> argument that only existed <strong>in volatile RAM</strong> and would be gone on shutdown.<br><br>Recover the file with <strong>fls + icat</strong>, then analyse with <strong>strings</strong> and <strong>Volatility3</strong>.',
 '<strong>Step 1</strong> — recover ram_capture.bin:<br><code>fls -r -d -o 133121 ctf1.img | grep ram</code><br><code>icat -o 133121 ctf1.img &lt;inode&gt; &gt; ram.dump</code><br><br><strong>Step 2</strong> — search for the key:<br><code>strings ram.dump | grep -E "key=|CmdLine|PID"</code><br><br><strong>Step 3</strong> — Volatility3 (real RAM dumps):<br><code>vol.py -f ram.dump windows.cmdline</code><br>Look for the <code>--key</code> argument of the suspicious process.',
 'fls,icat,strings,Volatility3,RAM,Volatile Memory',
 'Cywarx{v0l4t1l3_k3y5_d1s4pp34r}', 9),

-- 10
('Operation Phantom Ledger',
 'Full Investigation — All Concepts Combined',
 'EXPERT', 500, '#bc8cff',
 'Enron + WannaCry + CAID combined — a complete multi-stage investigation requiring every forensic technique covered in this course.',
 'Rohan Mehta stole <strong>75,842 customer records</strong> from IndusInd Bank, installed a keylogger, exfiltrated the data via FTP to a remote server, then deleted all evidence and formatted <code>ctf1.img</code>.<br><br>Apply every technique from challenges 1–9 in sequence. The final flag is inside the deleted <code>private_note.txt</code> — Rohan''s own crime plan. Recover it from P2 using <strong>fls + icat</strong>.',
 '<strong>Work through this checklist (no Python — forensic tools only):</strong><br><br>① <code>sha256sum ctf1.img</code> — chain of custody first<br>② <code>mmls ctf1.img</code> — map all partitions<br>③ <code>dd if=ctf1.img bs=512 count=1 | xxd</code> — read MBR (CH-05)<br>④ Mount P1 → <code>exiftool college_fest.jpg</code> (CH-02)<br>⑤ <code>fls -r -d -o 133121 ctf1.img</code> — list all deleted files<br>⑥ <code>icat -o 133121 ctf1.img &lt;inode&gt; &gt; private_note.txt</code><br>⑦ <code>cat private_note.txt</code> — read the flag',
 'sha256sum,mmls,dd,xxd,exiftool,fls,icat,strings,Chain of Custody',
 'Cywarx{ph4nt0m_l3dg3r_cl0s3d}', 10);
