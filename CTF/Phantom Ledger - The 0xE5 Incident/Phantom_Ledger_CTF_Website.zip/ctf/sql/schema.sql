-- ==========================================================
--  CYWARX CTF Platform — Database Schema
--  Run automatically by install/install.php
--  Or manually: mysql -u root -p < sql/schema.sql
-- ==========================================================

CREATE DATABASE IF NOT EXISTS CYWARX_ctf
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE CYWARX_ctf;

-- ----------------------------------------------------------
-- USERS  (students + admin)
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
  id          INT UNSIGNED     AUTO_INCREMENT PRIMARY KEY,
  full_name   VARCHAR(100)     NOT NULL,
  username    VARCHAR(50)      NOT NULL UNIQUE,
  password    VARCHAR(255)     NOT NULL,        -- bcrypt
  role        ENUM('student','admin') NOT NULL DEFAULT 'student',
  joined_at   DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------
-- CHALLENGES
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS challenges (
  id          INT UNSIGNED     AUTO_INCREMENT PRIMARY KEY,
  title       VARCHAR(120)     NOT NULL,
  topic       VARCHAR(120)     NOT NULL,
  difficulty  ENUM('EASY','EASY-MED','MEDIUM','MED-HARD','HARD','EXPERT')
              NOT NULL DEFAULT 'EASY',
  points      INT UNSIGNED     NOT NULL DEFAULT 50,
  accent      VARCHAR(7)       NOT NULL DEFAULT '#58a6ff',
  real_case   TEXT             NOT NULL,
  story       TEXT             NOT NULL,   -- HTML allowed
  hint        TEXT             NOT NULL,   -- HTML allowed, NO flags
  tags        VARCHAR(255)     NOT NULL DEFAULT '',
  flag        VARCHAR(255)     NOT NULL,   -- compared case-insensitively
  sort_order  INT UNSIGNED     NOT NULL DEFAULT 0,
  active      TINYINT(1)       NOT NULL DEFAULT 1,
  hint_enabled TINYINT(1)      NOT NULL DEFAULT 0   -- 0=locked, 1=visible to students
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------
-- SUBMISSIONS  (every attempt, correct or wrong)
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS submissions (
  id            INT UNSIGNED   AUTO_INCREMENT PRIMARY KEY,
  user_id       INT UNSIGNED   NOT NULL,
  challenge_id  INT UNSIGNED   NOT NULL,
  flag_input    VARCHAR(255)   NOT NULL,
  is_correct    TINYINT(1)     NOT NULL DEFAULT 0,
  submitted_at  DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id)      REFERENCES users(id)      ON DELETE CASCADE,
  FOREIGN KEY (challenge_id) REFERENCES challenges(id) ON DELETE CASCADE,
  INDEX idx_user_ch  (user_id, challenge_id),
  INDEX idx_submitted (submitted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------
-- SETTINGS  (key-value store, e.g. image hash)
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS settings (
  `key`   VARCHAR(80)  NOT NULL PRIMARY KEY,
  `value` TEXT         NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO settings (`key`, `value`) VALUES
  ('image_filename', 'ctf1.img'),
  ('image_sha256',   'Run sha256sum ctf1.img and paste the hash here via Admin › Settings');
