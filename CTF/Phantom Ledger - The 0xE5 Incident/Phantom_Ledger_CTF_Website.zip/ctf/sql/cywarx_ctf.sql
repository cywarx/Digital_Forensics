-- phpMyAdmin SQL Dump
-- version 5.2.3deb1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 06, 2026 at 12:03 PM
-- Server version: 11.8.6-MariaDB-4 from Debian
-- PHP Version: 8.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cywarx_ctf`
--

-- --------------------------------------------------------

--
-- Table structure for table `challenges`
--

CREATE TABLE `challenges` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(120) NOT NULL,
  `topic` varchar(120) NOT NULL,
  `difficulty` enum('EASY','EASY-MED','MEDIUM','MED-HARD','HARD','EXPERT') NOT NULL DEFAULT 'EASY',
  `points` int(10) UNSIGNED NOT NULL DEFAULT 50,
  `accent` varchar(7) NOT NULL DEFAULT '#58a6ff',
  `real_case` text NOT NULL,
  `story` text NOT NULL,
  `hint` text NOT NULL,
  `tags` varchar(255) NOT NULL DEFAULT '',
  `flag` varchar(255) NOT NULL,
  `sort_order` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `hint_enabled` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `challenges`
--

INSERT INTO `challenges` (`id`, `title`, `topic`, `difficulty`, `points`, `accent`, `real_case`, `story`, `hint`, `tags`, `flag`, `sort_order`, `active`, `hint_enabled`) VALUES
(1, 'What Am I Really?', 'File Signatures & Magic Bytes', 'EASY', 50, '#58a6ff', 'Enron — investigators identified renamed malware purely by reading raw hex byte signatures, ignoring the misleading file extension.', 'Suspect <strong>Rohan Mehta</strong> renamed his keylogger <code>invoice.exe</code> to look like an ordinary file before surrendering the device. It is deleted from the P2 (BACKUP) partition of <code>ctf1.img</code>.<br><br>Recover the deleted file using <strong>The Sleuth Kit</strong>, then run <strong>file</strong> and <strong>xxd</strong> on it. The file extension lies — the first two bytes never do.', '<strong>Step 1</strong> — find the deleted file:<br><code>mmls ctf1.img</code> then <code>fls -r -d -o 133121 ctf1.img</code> (note invoice.exe inode)<br><br><strong>Step 2</strong> — recover it:<br><code>icat -o 133121 ctf1.img &lt;inode&gt; &gt; recovered.bin</code><br><br><strong>Step 3</strong> — identify it:<br><code>file recovered.bin</code> and <code>xxd recovered.bin | head -2</code>', 'Magic Bytes,xxd,file,fls,icat,Sleuth Kit', 'Cywarx{MZ_exe_h1dd3n_4s_txt}', 1, 1, 0),
(2, 'The Metadata Witness', 'EXIF Metadata — OS Artifacts', 'EASY', 75, '#3fb950', 'Jill Dando murder — EXIF metadata and cell-tower records placed the suspect at the crime scene at the exact time of the murder, destroying his alibi.', 'Rohan claims he was at home all evening. He posted <code>college_fest.jpg</code> (P1 partition) and <code>fest_2024.jpg</code> (P2/Photos/) online — both silently carry GPS coordinates proving he was in Jaipur city centre at 14:32 on 17 March 2024.<br><br>A secret value is also embedded in the EXIF <code>UserComment</code> field, invisible to any normal viewer. Mount the partition and use <strong>exiftool</strong> to expose it.', '<strong>Step 1</strong> — mount P1 (offset = 2048 x 512 = 1,048,576 bytes):<br><code>sudo mount -o loop,offset=1048576 ctf1.img /mnt/p1</code><br><br><strong>Step 2</strong> — read all metadata:<br><code>exiftool /mnt/p1/college_fest.jpg</code><br><br><strong>Step 3</strong> — target the hidden field:<br><code>exiftool -UserComment /mnt/p1/college_fest.jpg</code>', 'EXIF,GPS,exiftool,mount', 'Cywarx{3x1f_k1ll5_4n0nym1ty}', 2, 1, 0),
(3, 'Deleted But Not Gone', 'FAT32 Deleted File Recovery', 'EASY-MED', 100, '#d29922', 'Corporate fraud — 200,000 deleted emails were fully recovered from executive drives, proving deliberate misconduct in court.', 'Rohan deleted <code>kl.log</code> — his keylogger output — from the FAT32 BACKUP partition of <code>ctf1.img</code> before surrendering the device.<br><br>In FAT32, deletion only marks the directory entry with <code>0xE5</code> — the actual data clusters are never erased. Use <strong>fls</strong> and <strong>icat</strong> to list and recover the file.', '<strong>Step 1</strong> — check layout:<br><code>mmls ctf1.img</code> (P2 = sector 133121)<br><br><strong>Step 2</strong> — list deleted files:<br><code>fls -r -d -o 133121 ctf1.img</code> (the * marks deleted entries — note kl.log inode)<br><br><strong>Step 3</strong> — recover and read:<br><code>icat -o 133121 ctf1.img &lt;inode&gt; &gt; kl.log</code> then <code>cat kl.log</code>', 'FAT32,fls,icat,mmls,Sleuth Kit', 'Cywarx{s3ct0r_z3r0_n3v3r_li3s}', 3, 1, 0),
(4, 'The MFT Never Forgets', 'NTFS Master File Table & Timestomping', 'MEDIUM', 150, '#58a6ff', 'WannaCry (2017) — analysts exposed the true malware install time using $FILE_NAME timestamps that the attackers could not modify without kernel access.', 'Inside <code>ntfs_evidence.img</code> — a visible file on P2 of <code>ctf1.img</code> — is a deleted <code>keylogger.exe</code> whose <code>$STANDARD_INFORMATION</code> timestamps were faked to <strong>2020-01-01 00:00:00</strong>.<br><br>NTFS stores a second set in <code>$FILE_NAME</code> that requires kernel access to modify. Mount the image and use <strong>istat</strong> to compare both sets and find the real install time.', '<strong>Step 1</strong> — mount P2:<br><code>sudo mount -o loop,offset=68157952 ctf1.img /mnt/p2</code><br><br><strong>Step 2</strong> — inspect with istat:<br><code>istat /mnt/p2/ntfs_evidence.img 2</code><br><br><strong>Step 3</strong> — use strings:<br><code>strings /mnt/p2/ntfs_evidence.img | grep -A4 \"STANDARD\"</code><br><br>When $STANDARD_INFORMATION and $FILE_NAME differ, timestomping occurred.', 'NTFS,MFT,istat,strings,Timestomping', 'Cywarx{t1m3st0mp_09}', 4, 1, 0),
(5, 'Sector Zero Speaks', 'Storage Fundamentals — MBR & Disk Structure', 'MEDIUM', 175, '#bc8cff', 'Manchester Arena bombing (2017) — investigators recovered communications hidden in raw disk sectors completely invisible to the operating system.', 'A <strong>13-byte string</strong> has been written at byte offset <code>0x100</code> (decimal 256) inside the MBR bootstrap code region of <code>ctf1.img</code>.<br><br>The MBR occupies the very first 512 bytes of every disk. The 446-byte bootstrap code area is never displayed by any file manager — making it a perfect hiding spot.', '<strong>Step 1</strong> — dump the MBR:<br><code>dd if=ctf1.img bs=512 count=1 | xxd</code><br><br><strong>Step 2</strong> — look at offset 0x100 and read the ASCII on the right<br><br><strong>Step 3</strong> — cleaner view:<br><code>xxd -s 256 -l 16 ctf1.img</code><br><br>Convert the 13 hex bytes at offset 256 to ASCII — that is your flag.', 'MBR,dd,xxd,Disk Structure,Hex', 'Cywarx{h3dd3n_m4rk3r}', 5, 1, 0),
(6, 'Quick Format? Think Again.', 'Formatted Partition Recovery — TestDisk', 'MED-HARD', 200, '#f0883e', 'Twitter hack (2020) — suspects quick-formatted drives moments before arrest; forensic teams recovered all data because no cluster data was erased.', 'Rohan quick-formatted the BACKUP partition in <code>ctf1.img</code> believing all evidence was gone. A quick format only rewrites the <strong>FAT header</strong> (the index map) — the actual data clusters are untouched.<br><br>Use <strong>TestDisk</strong> to rebuild the lost partition table, then mount and read <code>winscp_session.log</code> which contains FTP upload evidence and the flag.', '<strong>Step 1</strong> — run TestDisk:<br><code>testdisk ctf1.img</code> then Proceed > None > Analyse > Quick Search > Write<br><br><strong>Step 2</strong> — mount P2 (offset = 133121 x 512 = 68,157,952):<br><code>sudo mount -o loop,offset=68157952 ctf1.img /mnt/p2</code><br><br><strong>Step 3</strong> — read the log:<br><code>cat /mnt/p2/winscp_session.log</code>', 'TestDisk,FAT32,strings,Quick Format,Partition Recovery', 'Cywarx{qu1ck_f0rm4t_15_n0t_w1p3}', 6, 1, 0),
(7, 'Windows Never Forgets', 'OS Artifacts — Prefetch & Windows Event Logs', 'MED-HARD', 225, '#ff7ab2', 'Enron — Prefetch files proved that executives ran evidence-shredding software multiple times on the very day investigators arrived.', 'The deleted <code>ram_capture.bin</code> inside <code>ctf1.img</code> (P2 partition) is a simulated Windows artifact dump.<br><br>It records that <code>keylogger.exe</code> was executed <strong>7 times</strong>, and that Security <strong>EventID 1102</strong> fired — the event written when the Security log is deliberately cleared.', '<strong>Step 1</strong> — find the deleted file:<br><code>fls -r -d -o 133121 ctf1.img | grep ram_capture</code><br><br><strong>Step 2</strong> — recover it:<br><code>icat -o 133121 ctf1.img &lt;inode&gt; &gt; ram_capture.bin</code><br><br><strong>Step 3</strong> — search for evidence:<br><code>strings ram_capture.bin | grep -E \"Prefetch|EventID|ran|times\"</code>', 'fls,icat,strings,Prefetch,EventID 1102,Windows Artifacts', 'Cywarx{1102_ran_7_t1m3s}', 7, 1, 0),
(8, 'Carving the Void', 'Data Carving — File Signatures on Raw Bytes', 'HARD', 250, '#f85149', 'CAID investigations — images were carved from completely formatted drives using file signature matching, with no filesystem present at all.', 'The entire filesystem on P2 of <code>ctf1.img</code> has been destroyed. No partition table, no FAT, no directory tree — just raw bytes.<br><br>However, JPEG stubs and a ZIP archive are embedded in the raw cluster space. <strong>Foremost</strong> and <strong>Binwalk</strong> need no filesystem — they scan every byte for known magic byte signatures and carve out the files automatically.', '<strong>Step 1</strong> — carve with Foremost:<br><code>foremost -t jpg,zip -i ctf1.img -o /tmp/carved/</code><br>then check <code>cat /tmp/carved/audit.txt</code><br><br><strong>Step 2</strong> — extract the ZIP:<br><code>unzip /tmp/carved/zip/00000001.zip -d /tmp/evidence/</code><br><br><strong>Step 3</strong> — read the file:<br><code>cat /tmp/evidence/recovered_evidence.txt</code>', 'Foremost,Binwalk,Data Carving,Magic Bytes,unzip', 'Cywarx{c4rv1ng_f1nd5_th3_truth}', 8, 1, 0),
(9, 'RAM Knows Everything', 'Volatile Data & Memory Forensics', 'HARD', 300, '#3fb950', 'WannaCry (2017) — researchers extracted RSA encryption keys directly from live RAM before reboot, creating WanaKiwi which saved thousands of victims.', 'The deleted <code>ram_capture.bin</code> inside <code>ctf1.img</code> is a simulated Windows memory dump. It holds the full command-line of PID 1337 (<code>keylogger.exe</code>) including an encryption key passed as a <code>--key</code> argument that only existed <strong>in volatile RAM</strong> and would be gone on shutdown.', '<strong>Step 1</strong> — recover ram_capture.bin:<br><code>fls -r -d -o 133121 ctf1.img | grep ram</code><br><code>icat -o 133121 ctf1.img &lt;inode&gt; &gt; ram.dump</code><br><br><strong>Step 2</strong> — search for the key:<br><code>strings ram.dump | grep -E \"key=|CmdLine|PID\"</code><br><br><strong>Step 3</strong> — Volatility3 (real RAM dumps):<br><code>vol.py -f ram.dump windows.cmdline</code>', 'fls,icat,strings,Volatility3,RAM,Volatile Memory', 'Cywarx{v0l4t1l3_k3y5_d1s4pp34r}', 9, 1, 0),
(10, 'Operation Phantom Ledger', 'Full Investigation — All Concepts Combined', 'EXPERT', 500, '#bc8cff', 'Enron + WannaCry + CAID combined — a complete multi-stage investigation requiring every forensic technique covered in this course.', 'Rohan Mehta stole <strong>75,842 customer records</strong> from IndusInd Bank, installed a keylogger, exfiltrated the data via FTP to a remote server, then deleted all evidence and formatted <code>ctf1.img</code>.<br><br>Apply every technique from challenges 1 to 9 in sequence. The final flag is inside the deleted <code>private_note.txt</code> — recover it from P2 using <strong>fls + icat</strong>.', '<strong>Work through this checklist:</strong><br><br>1. <code>sha256sum ctf1.img</code> — chain of custody first<br>2. <code>mmls ctf1.img</code> — map all partitions<br>3. <code>dd if=ctf1.img bs=512 count=1 | xxd</code> — read MBR<br>4. Mount P1, run <code>exiftool college_fest.jpg</code><br>5. <code>fls -r -d -o 133121 ctf1.img</code> — list all deleted files<br>6. <code>icat -o 133121 ctf1.img &lt;inode&gt; &gt; private_note.txt</code><br>7. <code>cat private_note.txt</code> — read the flag', 'sha256sum,mmls,dd,xxd,exiftool,fls,icat,strings,Chain of Custody', 'Cywarx{ph4nt0m_l3dg3r_cl0s3d}', 10, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `key` varchar(80) NOT NULL,
  `value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`key`, `value`) VALUES
('image_filename', 'ctf1.img'),
('image_sha256', 'Run sha256sum ctf1.img and paste the hash here via Admin Settings');

-- --------------------------------------------------------

--
-- Table structure for table `submissions`
--

CREATE TABLE `submissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `challenge_id` int(10) UNSIGNED NOT NULL,
  `flag_input` varchar(255) NOT NULL,
  `is_correct` tinyint(1) NOT NULL DEFAULT 0,
  `submitted_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `submissions`
--

INSERT INTO `submissions` (`id`, `user_id`, `challenge_id`, `flag_input`, `is_correct`, `submitted_at`) VALUES
(1, 2, 1, 'Cywarx{MZ_exe_h1dd3n_4s_txt}', 1, '2026-04-06 17:27:36');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('student','admin') NOT NULL DEFAULT 'student',
  `joined_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `username`, `password`, `role`, `joined_at`) VALUES
(1, 'Administrator', 'admin', '$2y$12$v8ekXC6zKXyIupPSSSx4z.xiwZCZOJbG8CNu/Fn/Bdr441jqPQ.4e', 'admin', '2026-04-06 17:10:52'),
(2, 'hexx', 'hexx', '$2y$12$E7sc3Al1D2oQJ6bv/M5wTeLCuls8ewe5Np1vvmLBdy5AA453R77IK', 'student', '2026-04-06 17:27:30');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `challenges`
--
ALTER TABLE `challenges`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `submissions`
--
ALTER TABLE `submissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `challenge_id` (`challenge_id`),
  ADD KEY `idx_user_ch` (`user_id`,`challenge_id`),
  ADD KEY `idx_submitted` (`submitted_at`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `idx_username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `challenges`
--
ALTER TABLE `challenges`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `submissions`
--
ALTER TABLE `submissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `submissions`
--
ALTER TABLE `submissions`
  ADD CONSTRAINT `submissions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `submissions_ibfk_2` FOREIGN KEY (`challenge_id`) REFERENCES `challenges` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
