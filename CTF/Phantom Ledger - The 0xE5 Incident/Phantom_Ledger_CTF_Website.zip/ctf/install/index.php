<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

$cfgPath = __DIR__ . '/../includes/config.php';
$dbHost  = 'localhost';
$dbName  = 'cywarx_ctf';
$dbUser  = 'root';
$dbPass  = 'Warrior@007';
$baseUrl = '/ctf';

if (file_exists($cfgPath)) {
    $cfg = file_get_contents($cfgPath);
    if (preg_match("/define\('DB_HOST',\s*'([^']+)'\)/",  $cfg, $m)) $dbHost  = $m[1];
    if (preg_match("/define\('DB_NAME',\s*'([^']+)'\)/",  $cfg, $m)) $dbName  = $m[1];
    if (preg_match("/define\('DB_USER',\s*'([^']+)'\)/",  $cfg, $m)) $dbUser  = $m[1];
    if (preg_match("/define\('DB_PASS',\s*'([^']*)'\)/",  $cfg, $m)) $dbPass  = $m[1];
    if (preg_match("/define\('BASE_URL',\s*'([^']*)'\)/", $cfg, $m)) $baseUrl = $m[1];
}

// ============================================================
//  ALL 10 CHALLENGES — defined as PHP arrays, inserted via
//  PDO prepared statements so no SQL injection / quoting issues
// ============================================================
function get_challenges_data() {
    return array(
        array(
            'title'      => 'What Am I Really?',
            'topic'      => 'File Signatures & Magic Bytes',
            'difficulty' => 'EASY',
            'points'     => 50,
            'accent'     => '#58a6ff',
            'real_case'  => 'Enron — investigators identified renamed malware purely by reading raw hex byte signatures, ignoring the misleading file extension.',
            'story'      => 'Suspect <strong>Rohan Mehta</strong> renamed his keylogger <code>invoice.exe</code> to look like an ordinary file before surrendering the device. It is deleted from the P2 (BACKUP) partition of <code>ctf1.img</code>.<br><br>Recover the deleted file using <strong>The Sleuth Kit</strong>, then run <strong>file</strong> and <strong>xxd</strong> on it. The file extension lies — the first two bytes never do.',
            'hint'       => '<strong>Step 1</strong> — find the deleted file:<br><code>mmls ctf1.img</code> then <code>fls -r -d -o 133121 ctf1.img</code> (note invoice.exe inode)<br><br><strong>Step 2</strong> — recover it:<br><code>icat -o 133121 ctf1.img &lt;inode&gt; &gt; recovered.bin</code><br><br><strong>Step 3</strong> — identify it:<br><code>file recovered.bin</code> and <code>xxd recovered.bin | head -2</code>',
            'tags'       => 'Magic Bytes,xxd,file,fls,icat,Sleuth Kit',
            'flag'       => 'Cywarx{MZ_exe_h1dd3n_4s_txt}',
            'sort_order' => 1,
        ),
        array(
            'title'      => 'The Metadata Witness',
            'topic'      => 'EXIF Metadata — OS Artifacts',
            'difficulty' => 'EASY',
            'points'     => 75,
            'accent'     => '#3fb950',
            'real_case'  => 'Jill Dando murder — EXIF metadata and cell-tower records placed the suspect at the crime scene at the exact time of the murder, destroying his alibi.',
            'story'      => 'Rohan claims he was at home all evening. He posted <code>college_fest.jpg</code> (P1 partition) and <code>fest_2024.jpg</code> (P2/Photos/) online — both silently carry GPS coordinates proving he was in Jaipur city centre at 14:32 on 17 March 2024.<br><br>A secret value is also embedded in the EXIF <code>UserComment</code> field, invisible to any normal viewer. Mount the partition and use <strong>exiftool</strong> to expose it.',
            'hint'       => '<strong>Step 1</strong> — mount P1 (offset = 2048 x 512 = 1,048,576 bytes):<br><code>sudo mount -o loop,offset=1048576 ctf1.img /mnt/p1</code><br><br><strong>Step 2</strong> — read all metadata:<br><code>exiftool /mnt/p1/college_fest.jpg</code><br><br><strong>Step 3</strong> — target the hidden field:<br><code>exiftool -UserComment /mnt/p1/college_fest.jpg</code>',
            'tags'       => 'EXIF,GPS,exiftool,mount',
            'flag'       => 'Cywarx{3x1f_k1ll5_4n0nym1ty}',
            'sort_order' => 2,
        ),
        array(
            'title'      => 'Deleted But Not Gone',
            'topic'      => 'FAT32 Deleted File Recovery',
            'difficulty' => 'EASY-MED',
            'points'     => 100,
            'accent'     => '#d29922',
            'real_case'  => 'Corporate fraud — 200,000 deleted emails were fully recovered from executive drives, proving deliberate misconduct in court.',
            'story'      => 'Rohan deleted <code>kl.log</code> — his keylogger output — from the FAT32 BACKUP partition of <code>ctf1.img</code> before surrendering the device.<br><br>In FAT32, deletion only marks the directory entry with <code>0xE5</code> — the actual data clusters are never erased. Use <strong>fls</strong> and <strong>icat</strong> to list and recover the file.',
            'hint'       => '<strong>Step 1</strong> — check layout:<br><code>mmls ctf1.img</code> (P2 = sector 133121)<br><br><strong>Step 2</strong> — list deleted files:<br><code>fls -r -d -o 133121 ctf1.img</code> (the * marks deleted entries — note kl.log inode)<br><br><strong>Step 3</strong> — recover and read:<br><code>icat -o 133121 ctf1.img &lt;inode&gt; &gt; kl.log</code> then <code>cat kl.log</code>',
            'tags'       => 'FAT32,fls,icat,mmls,Sleuth Kit',
            'flag'       => 'Cywarx{s3ct0r_z3r0_n3v3r_li3s}',
            'sort_order' => 3,
        ),
        array(
            'title'      => 'The MFT Never Forgets',
            'topic'      => 'NTFS Master File Table & Timestomping',
            'difficulty' => 'MEDIUM',
            'points'     => 150,
            'accent'     => '#58a6ff',
            'real_case'  => 'WannaCry (2017) — analysts exposed the true malware install time using $FILE_NAME timestamps that the attackers could not modify without kernel access.',
            'story'      => 'Inside <code>ntfs_evidence.img</code> — a visible file on P2 of <code>ctf1.img</code> — is a deleted <code>keylogger.exe</code> whose <code>$STANDARD_INFORMATION</code> timestamps were faked to <strong>2020-01-01 00:00:00</strong>.<br><br>NTFS stores a second set in <code>$FILE_NAME</code> that requires kernel access to modify. Mount the image and use <strong>istat</strong> to compare both sets and find the real install time.',
            'hint'       => '<strong>Step 1</strong> — mount P2:<br><code>sudo mount -o loop,offset=68157952 ctf1.img /mnt/p2</code><br><br><strong>Step 2</strong> — inspect with istat:<br><code>istat /mnt/p2/ntfs_evidence.img 2</code><br><br><strong>Step 3</strong> — use strings:<br><code>strings /mnt/p2/ntfs_evidence.img | grep -A4 "STANDARD"</code><br><br>When $STANDARD_INFORMATION and $FILE_NAME differ, timestomping occurred.',
            'tags'       => 'NTFS,MFT,istat,strings,Timestomping',
            'flag'       => 'Cywarx{t1m3st0mp_09}',
            'sort_order' => 4,
        ),
        array(
            'title'      => 'Sector Zero Speaks',
            'topic'      => 'Storage Fundamentals — MBR & Disk Structure',
            'difficulty' => 'MEDIUM',
            'points'     => 175,
            'accent'     => '#bc8cff',
            'real_case'  => 'Manchester Arena bombing (2017) — investigators recovered communications hidden in raw disk sectors completely invisible to the operating system.',
            'story'      => 'A <strong>13-byte string</strong> has been written at byte offset <code>0x100</code> (decimal 256) inside the MBR bootstrap code region of <code>ctf1.img</code>.<br><br>The MBR occupies the very first 512 bytes of every disk. The 446-byte bootstrap code area is never displayed by any file manager — making it a perfect hiding spot.',
            'hint'       => '<strong>Step 1</strong> — dump the MBR:<br><code>dd if=ctf1.img bs=512 count=1 | xxd</code><br><br><strong>Step 2</strong> — look at offset 0x100 and read the ASCII on the right<br><br><strong>Step 3</strong> — cleaner view:<br><code>xxd -s 256 -l 16 ctf1.img</code><br><br>Convert the 13 hex bytes at offset 256 to ASCII — that is your flag.',
            'tags'       => 'MBR,dd,xxd,Disk Structure,Hex',
            'flag'       => 'Cywarx{h3dd3n_m4rk3r}',
            'sort_order' => 5,
        ),
        array(
            'title'      => 'Quick Format? Think Again.',
            'topic'      => 'Formatted Partition Recovery — TestDisk',
            'difficulty' => 'MED-HARD',
            'points'     => 200,
            'accent'     => '#f0883e',
            'real_case'  => 'Twitter hack (2020) — suspects quick-formatted drives moments before arrest; forensic teams recovered all data because no cluster data was erased.',
            'story'      => 'Rohan quick-formatted the BACKUP partition in <code>ctf1.img</code> believing all evidence was gone. A quick format only rewrites the <strong>FAT header</strong> (the index map) — the actual data clusters are untouched.<br><br>Use <strong>TestDisk</strong> to rebuild the lost partition table, then mount and read <code>winscp_session.log</code> which contains FTP upload evidence and the flag.',
            'hint'       => '<strong>Step 1</strong> — run TestDisk:<br><code>testdisk ctf1.img</code> then Proceed > None > Analyse > Quick Search > Write<br><br><strong>Step 2</strong> — mount P2 (offset = 133121 x 512 = 68,157,952):<br><code>sudo mount -o loop,offset=68157952 ctf1.img /mnt/p2</code><br><br><strong>Step 3</strong> — read the log:<br><code>cat /mnt/p2/winscp_session.log</code>',
            'tags'       => 'TestDisk,FAT32,strings,Quick Format,Partition Recovery',
            'flag'       => 'Cywarx{qu1ck_f0rm4t_15_n0t_w1p3}',
            'sort_order' => 6,
        ),
        array(
            'title'      => 'Windows Never Forgets',
            'topic'      => 'OS Artifacts — Prefetch & Windows Event Logs',
            'difficulty' => 'MED-HARD',
            'points'     => 225,
            'accent'     => '#ff7ab2',
            'real_case'  => 'Enron — Prefetch files proved that executives ran evidence-shredding software multiple times on the very day investigators arrived.',
            'story'      => 'The deleted <code>ram_capture.bin</code> inside <code>ctf1.img</code> (P2 partition) is a simulated Windows artifact dump.<br><br>It records that <code>keylogger.exe</code> was executed <strong>7 times</strong>, and that Security <strong>EventID 1102</strong> fired — the event written when the Security log is deliberately cleared.',
            'hint'       => '<strong>Step 1</strong> — find the deleted file:<br><code>fls -r -d -o 133121 ctf1.img | grep ram_capture</code><br><br><strong>Step 2</strong> — recover it:<br><code>icat -o 133121 ctf1.img &lt;inode&gt; &gt; ram_capture.bin</code><br><br><strong>Step 3</strong> — search for evidence:<br><code>strings ram_capture.bin | grep -E "Prefetch|EventID|ran|times"</code>',
            'tags'       => 'fls,icat,strings,Prefetch,EventID 1102,Windows Artifacts',
            'flag'       => 'Cywarx{1102_ran_7_t1m3s}',
            'sort_order' => 7,
        ),
        array(
            'title'      => 'Carving the Void',
            'topic'      => 'Data Carving — File Signatures on Raw Bytes',
            'difficulty' => 'HARD',
            'points'     => 250,
            'accent'     => '#f85149',
            'real_case'  => 'CAID investigations — images were carved from completely formatted drives using file signature matching, with no filesystem present at all.',
            'story'      => 'The entire filesystem on P2 of <code>ctf1.img</code> has been destroyed. No partition table, no FAT, no directory tree — just raw bytes.<br><br>However, JPEG stubs and a ZIP archive are embedded in the raw cluster space. <strong>Foremost</strong> and <strong>Binwalk</strong> need no filesystem — they scan every byte for known magic byte signatures and carve out the files automatically.',
            'hint'       => '<strong>Step 1</strong> — carve with Foremost:<br><code>foremost -t jpg,zip -i ctf1.img -o /tmp/carved/</code><br>then check <code>cat /tmp/carved/audit.txt</code><br><br><strong>Step 2</strong> — extract the ZIP:<br><code>unzip /tmp/carved/zip/00000001.zip -d /tmp/evidence/</code><br><br><strong>Step 3</strong> — read the file:<br><code>cat /tmp/evidence/recovered_evidence.txt</code>',
            'tags'       => 'Foremost,Binwalk,Data Carving,Magic Bytes,unzip',
            'flag'       => 'Cywarx{c4rv1ng_f1nd5_th3_truth}',
            'sort_order' => 8,
        ),
        array(
            'title'      => 'RAM Knows Everything',
            'topic'      => 'Volatile Data & Memory Forensics',
            'difficulty' => 'HARD',
            'points'     => 300,
            'accent'     => '#3fb950',
            'real_case'  => 'WannaCry (2017) — researchers extracted RSA encryption keys directly from live RAM before reboot, creating WanaKiwi which saved thousands of victims.',
            'story'      => 'The deleted <code>ram_capture.bin</code> inside <code>ctf1.img</code> is a simulated Windows memory dump. It holds the full command-line of PID 1337 (<code>keylogger.exe</code>) including an encryption key passed as a <code>--key</code> argument that only existed <strong>in volatile RAM</strong> and would be gone on shutdown.',
            'hint'       => '<strong>Step 1</strong> — recover ram_capture.bin:<br><code>fls -r -d -o 133121 ctf1.img | grep ram</code><br><code>icat -o 133121 ctf1.img &lt;inode&gt; &gt; ram.dump</code><br><br><strong>Step 2</strong> — search for the key:<br><code>strings ram.dump | grep -E "key=|CmdLine|PID"</code><br><br><strong>Step 3</strong> — Volatility3 (real RAM dumps):<br><code>vol.py -f ram.dump windows.cmdline</code>',
            'tags'       => 'fls,icat,strings,Volatility3,RAM,Volatile Memory',
            'flag'       => 'Cywarx{v0l4t1l3_k3y5_d1s4pp34r}',
            'sort_order' => 9,
        ),
        array(
            'title'      => 'Operation Phantom Ledger',
            'topic'      => 'Full Investigation — All Concepts Combined',
            'difficulty' => 'EXPERT',
            'points'     => 500,
            'accent'     => '#bc8cff',
            'real_case'  => 'Enron + WannaCry + CAID combined — a complete multi-stage investigation requiring every forensic technique covered in this course.',
            'story'      => 'Rohan Mehta stole <strong>75,842 customer records</strong> from IndusInd Bank, installed a keylogger, exfiltrated the data via FTP to a remote server, then deleted all evidence and formatted <code>ctf1.img</code>.<br><br>Apply every technique from challenges 1 to 9 in sequence. The final flag is inside the deleted <code>private_note.txt</code> — recover it from P2 using <strong>fls + icat</strong>.',
            'hint'       => '<strong>Work through this checklist:</strong><br><br>1. <code>sha256sum ctf1.img</code> — chain of custody first<br>2. <code>mmls ctf1.img</code> — map all partitions<br>3. <code>dd if=ctf1.img bs=512 count=1 | xxd</code> — read MBR<br>4. Mount P1, run <code>exiftool college_fest.jpg</code><br>5. <code>fls -r -d -o 133121 ctf1.img</code> — list all deleted files<br>6. <code>icat -o 133121 ctf1.img &lt;inode&gt; &gt; private_note.txt</code><br>7. <code>cat private_note.txt</code> — read the flag',
            'tags'       => 'sha256sum,mmls,dd,xxd,exiftool,fls,icat,strings,Chain of Custody',
            'flag'       => 'Cywarx{ph4nt0m_l3dg3r_cl0s3d}',
            'sort_order' => 10,
        ),
    );
}

$results = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'install') {

    $dbHost  = trim($_POST['db_host']    ?? 'localhost');
    $dbName  = trim($_POST['db_name']    ?? 'cywarx_ctf');
    $dbUser  = trim($_POST['db_user']    ?? 'root');
    $dbPass  =       $_POST['db_pass']   ?? 'Warrior@007';
    $baseUrl = rtrim(trim($_POST['base_url'] ?? '/ctf'), '/');
    $adminPw = trim($_POST['admin_pass'] ?? 'Warrior@007');

    if (strlen($adminPw) < 6) {
        $results[] = array('err', 'Admin password must be at least 6 characters.');
        goto done;
    }

    // Step 1: Connect
    try {
        $pdo = new PDO(
            "mysql:host=$dbHost;charset=utf8mb4",
            $dbUser, $dbPass,
            array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION)
        );
        $results[] = array('ok', 'Database connection successful.');
    } catch (PDOException $e) {
        $results[] = array('err', 'DB connection failed: ' . $e->getMessage());
        goto done;
    }

    // Step 2: Create DB
    try {
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `$dbName` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $pdo->exec("USE `$dbName`");
        $results[] = array('ok', "Database '$dbName' ready.");
    } catch (PDOException $e) {
        $results[] = array('err', 'Could not create database: ' . $e->getMessage());
        goto done;
    }

    // Step 3: Create tables
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS users (
            id        INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            full_name VARCHAR(100) NOT NULL,
            username  VARCHAR(50)  NOT NULL UNIQUE,
            password  VARCHAR(255) NOT NULL,
            role      ENUM('student','admin') NOT NULL DEFAULT 'student',
            joined_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_username (username)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $pdo->exec("CREATE TABLE IF NOT EXISTS challenges (
            id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            title       VARCHAR(120) NOT NULL,
            topic       VARCHAR(120) NOT NULL,
            difficulty  ENUM('EASY','EASY-MED','MEDIUM','MED-HARD','HARD','EXPERT') NOT NULL DEFAULT 'EASY',
            points      INT UNSIGNED NOT NULL DEFAULT 50,
            accent      VARCHAR(7)   NOT NULL DEFAULT '#58a6ff',
            real_case   TEXT NOT NULL,
            story       TEXT NOT NULL,
            hint        TEXT NOT NULL,
            tags        VARCHAR(255) NOT NULL DEFAULT '',
            flag        VARCHAR(255) NOT NULL,
            sort_order  INT UNSIGNED NOT NULL DEFAULT 0,
            active      TINYINT(1)   NOT NULL DEFAULT 1
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $pdo->exec("CREATE TABLE IF NOT EXISTS submissions (
            id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id       INT UNSIGNED NOT NULL,
            challenge_id  INT UNSIGNED NOT NULL,
            flag_input    VARCHAR(255) NOT NULL,
            is_correct    TINYINT(1)   NOT NULL DEFAULT 0,
            submitted_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id)     REFERENCES users(id)      ON DELETE CASCADE,
            FOREIGN KEY (challenge_id) REFERENCES challenges(id) ON DELETE CASCADE,
            INDEX idx_user_ch  (user_id, challenge_id),
            INDEX idx_submitted (submitted_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $pdo->exec("CREATE TABLE IF NOT EXISTS settings (
            `key`   VARCHAR(80) NOT NULL PRIMARY KEY,
            `value` TEXT        NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $pdo->exec("INSERT IGNORE INTO settings (`key`,`value`) VALUES
            ('image_filename','ctf1.img'),
            ('image_sha256','Run sha256sum ctf1.img and paste the hash here via Admin Settings')");

        $results[] = array('ok', 'All tables created successfully.');
    } catch (PDOException $e) {
        $results[] = array('err', 'Table creation error: ' . $e->getMessage());
        goto done;
    }

    // Step 4: Seed challenges using prepared statements (no SQL injection issues)
    try {
        $pdo->exec('SET FOREIGN_KEY_CHECKS = 0');
        $pdo->exec('TRUNCATE TABLE challenges');
        $pdo->exec('SET FOREIGN_KEY_CHECKS = 1');

        $st = $pdo->prepare(
            'INSERT INTO challenges
             (title, topic, difficulty, points, accent, real_case, story, hint, tags, flag, sort_order)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
        );

        foreach (get_challenges_data() as $ch) {
            $st->execute(array(
                $ch['title'],
                $ch['topic'],
                $ch['difficulty'],
                $ch['points'],
                $ch['accent'],
                $ch['real_case'],
                $ch['story'],
                $ch['hint'],
                $ch['tags'],
                $ch['flag'],
                $ch['sort_order'],
            ));
        }
        $results[] = array('ok', '10 challenges inserted successfully.');
    } catch (PDOException $e) {
        $pdo->exec('SET FOREIGN_KEY_CHECKS = 1');
        $results[] = array('err', 'Challenge insert error: ' . $e->getMessage());
        goto done;
    }

    // Step 5: Create admin
    try {
        $hash = password_hash($adminPw, PASSWORD_BCRYPT, array('cost' => 12));
        $pdo->exec("DELETE FROM users WHERE username = 'admin'");
        $st = $pdo->prepare(
            "INSERT INTO users (full_name, username, password, role)
             VALUES ('Administrator', 'admin', ?, 'admin')"
        );
        $st->execute(array($hash));
        $results[] = array('ok', 'Admin account created. Username: admin');
    } catch (PDOException $e) {
        $results[] = array('err', 'Admin account error: ' . $e->getMessage());
        goto done;
    }

    // Step 6: Update config.php
    try {
        $cfg = file_get_contents($cfgPath);
        $cfg = preg_replace("/define\('DB_HOST',\s*'[^']*'\)/",  "define('DB_HOST',    '$dbHost')", $cfg);
        $cfg = preg_replace("/define\('DB_NAME',\s*'[^']*'\)/",  "define('DB_NAME',    '$dbName')", $cfg);
        $cfg = preg_replace("/define\('DB_USER',\s*'[^']*'\)/",  "define('DB_USER',    '$dbUser')", $cfg);
        $cfg = preg_replace("/define\('DB_PASS',\s*'[^']*'\)/",  "define('DB_PASS',    '$dbPass')", $cfg);
        $cfg = preg_replace("/define\('BASE_URL',\s*'[^']*'\)/", "define('BASE_URL', '$baseUrl')",  $cfg);
        file_put_contents($cfgPath, $cfg);
        $results[] = array('ok', 'config.php updated with your database settings.');
    } catch (Exception $e) {
        $results[] = array('err', 'Could not write config.php: ' . $e->getMessage());
    }

    $success = true;
    done:
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>cywarx CTF Installer</title>
<style>
*{box-sizing:border-box;margin:0;padding:0;}
body{background:#0d1117;color:#e6edf3;font-family:'Segoe UI',sans-serif;
     min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px;}
.box{background:#161b22;border:1px solid #30363d;border-radius:12px;width:100%;max-width:500px;overflow:hidden;}
.hdr{padding:24px 28px 16px;border-bottom:1px solid #30363d;text-align:center;}
.logo{font-size:22px;font-weight:800;}.logo span{color:#58a6ff;}
.sub{font-size:11px;color:#3d444d;letter-spacing:2px;text-transform:uppercase;margin-top:4px;}
.body{padding:22px 28px;display:flex;flex-direction:column;gap:13px;}
label{display:block;font-size:12px;font-weight:600;color:#8b949e;margin-bottom:4px;}
input[type=text],input[type=password]{width:100%;background:#0d1117;border:1px solid #30363d;
  border-radius:6px;color:#e6edf3;padding:9px 12px;font-size:14px;outline:none;}
input:focus{border-color:#58a6ff;}
.hint{font-size:11px;color:#3d444d;margin-top:3px;}
.btn{width:100%;padding:11px;background:#58a6ff;color:#0d1117;border:none;
     border-radius:6px;font-size:14px;font-weight:700;cursor:pointer;}
.btn:hover{background:#79b8ff;}
.ok{padding:9px 12px;border-radius:6px;font-size:13px;
    background:rgba(63,185,80,.1);border:1px solid rgba(63,185,80,.28);color:#3fb950;}
.err{padding:9px 12px;border-radius:6px;font-size:13px;
     background:rgba(248,81,73,.1);border:1px solid rgba(248,81,73,.28);color:#f85149;}
.step{padding:7px 0;border-bottom:1px solid #30363d;font-size:13px;display:flex;gap:8px;}
.step:last-child{border-bottom:none;}
.warn{padding:10px 12px;border-radius:6px;font-size:13px;line-height:1.6;
      background:rgba(210,153,34,.1);border:1px solid rgba(210,153,34,.28);color:#d29922;}
code{font-family:monospace;font-size:.85em;background:#1c2330;padding:1px 5px;border-radius:3px;color:#58a6ff;}
a.go{display:block;width:100%;padding:11px;background:#3fb950;color:#0d1117;border-radius:6px;
     font-size:14px;font-weight:700;text-align:center;text-decoration:none;margin-top:4px;}
</style>
</head>
<body>
<div class="box">
  <div class="hdr">
    <div class="logo">CY<span>WARX</span> CTF</div>
    <div class="sub">Installer</div>
  </div>

<?php if ($success): ?>
  <div class="body">
    <div class="ok">&#10003; Installation complete!</div>
    <?php foreach ($results as $r): ?>
      <div class="step">
        <span style="color:<?php echo $r[0]==='ok'?'#3fb950':'#f85149'; ?>"><?php echo $r[0]==='ok'?'&#10003;':'&#10007;'; ?></span>
        <span style="color:<?php echo $r[0]==='ok'?'#3fb950':'#f85149'; ?>"><?php echo $r[1]; ?></span>
      </div>
    <?php endforeach; ?>
    <div class="warn">
      &#9888; Delete the install folder now:<br>
      <code>sudo rm -rf /var/www/html/ctf/install/</code>
    </div>
    <a class="go" href="<?php echo htmlspecialchars($baseUrl); ?>/pages/login.php">Go to Login Page &#8594;</a>
    <p style="font-size:12px;color:#3d444d;text-align:center;">Login with username: <code>admin</code></p>
  </div>
<?php else: ?>
  <form class="body" method="POST">
    <input type="hidden" name="action" value="install">
    <?php foreach ($results as $r): ?>
      <div class="<?php echo $r[0]; ?>"><?php echo $r[1]; ?></div>
    <?php endforeach; ?>
    <p style="font-size:13px;color:#8b949e;line-height:1.6;">
      Fill in your MySQL details and choose an admin password.
    </p>
    <div>
      <label>DB Host</label>
      <input type="text" name="db_host" value="<?php echo htmlspecialchars($dbHost); ?>" required>
    </div>
    <div>
      <label>DB Name</label>
      <input type="text" name="db_name" value="<?php echo htmlspecialchars($dbName); ?>" required>
      <div class="hint">Created automatically if it does not exist.</div>
    </div>
    <div>
      <label>DB Username</label>
      <input type="text" name="db_user" value="<?php echo htmlspecialchars($dbUser); ?>" required>
    </div>
    <div>
      <label>DB Password</label>
      <input type="password" name="db_pass" value="<?php echo htmlspecialchars($dbPass); ?>" placeholder="e.g. Warrior@007">
    </div>
    <div>
      <label>Base URL Path</label>
      <input type="text" name="base_url" value="<?php echo htmlspecialchars($baseUrl); ?>" placeholder="/ctf">
      <div class="hint">If your URL is <code>http://localhost:8080/ctf</code> enter <code>/ctf</code></div>
    </div>
    <div>
      <label>Admin Password</label>
      <input type="password" name="admin_pass" placeholder="Min 6 characters" required>
    </div>
    <button type="submit" class="btn">Run Installation</button>
    <p style="font-size:12px;color:#3d444d;text-align:center;">DB: user=<code>root</code> pass=<code>Warrior@007</code></p>
  </form>
<?php endif; ?>
</div>
</body>
</html>
