# CYWRAX CTF Platform

A self-contained PHP + MySQL CTF platform for Digital Forensics courses.
Student accounts, progress, scores, and submissions persist in MySQL permanently.

---

## Quick Start (XAMPP — Windows / Mac / Linux)

### Step 1 — Download and install XAMPP

https://www.apachefriends.org

Start both **Apache** and **MySQL** from the XAMPP control panel.

---

### Step 2 — Copy this project

Copy the entire `cywrax/` folder into:

```
Windows : C:\xampp\htdocs\cywrax\
Mac/Linux: /opt/lampp/htdocs/cywrax/
```

---

### Step 3 — Run the installer

Open your browser and go to:

```
http://localhost/cywrax/install/
```

Fill in the form:

| Field         | XAMPP Default |
|---------------|---------------|
| DB Host       | `localhost`   |
| DB Name       | `cywrax_ctf`  |
| DB Username   | `root`        |
| DB Password   | *(leave blank)*|
| Base URL path | `/cywrax`     |
| Admin Password| Choose one (min 6 chars) |

Click **Run Installation**. The installer will:
- Create the `cywrax_ctf` database
- Create all tables
- Seed all 10 challenges
- Create the admin account
- Update `includes/config.php` automatically

---

### Step 4 — Delete the install folder ⚠️

After installation, delete or rename the `install/` folder:

```bash
# Windows: rename or delete C:\xampp\htdocs\cywrax\install\
# Linux/Mac:
rm -rf /opt/lampp/htdocs/cywrax/install/
```

```sql
ALTER TABLE challenges ADD COLUMN hint_enabled TINYINT(1) NOT NULL DEFAULT 0;
```

**This is important** — leaving it accessible lets anyone re-run the installer.

---

### Step 5 — Open the site

```
http://localhost/cywrax/
```

- **Students** → Sign Up → Dashboard
- **Admin** → Login with `admin` / your chosen password

---

## File Structure

```
cywrax/
├── index.php                    ← redirects to login
├── install/
│   └── index.php                ← one-click installer (delete after setup)
├── sql/
│   ├── schema.sql               ← database tables
│   └── challenges.sql           ← all 10 challenge records
├── includes/
│   ├── config.php               ← DB credentials + BASE_URL (auto-updated by installer)
│   ├── auth.php                 ← login, signup, session, CSRF guards
│   ├── challenges.php           ← DB helpers: get challenges, submit flag, scoreboard
│   └── layout.php               ← shared HTML partials (nav, head, footer, modals)
├── pages/
│   ├── login.php                ← student + admin login
│   ├── signup.php               ← student self-registration
│   ├── logout.php
│   ├── dashboard.php            ← student challenge board
│   ├── leaderboard.php          ← student leaderboard
│   ├── profile.php              ← student personal progress
│   ├── get_challenge.php        ← AJAX: returns challenge JSON
│   ├── submit_flag.php          ← AJAX: flag submission endpoint
│   └── admin/
│       ├── index.php            ← admin overview + recent submissions
│       ├── students.php         ← manage students (add/remove/reset password)
│       ├── scoreboard.php       ← full scoreboard, click row for student progress
│       ├── challenges.php       ← challenge list with flags (admin-only view)
│       ├── settings.php         ← image filename + SHA256 hash settings
│       ├── student_progress.php ← AJAX: returns student progress HTML fragment
│       └── partials/
│           └── progress_modal.php ← shared modal HTML included by admin pages
└── assets/
    ├── css/style.css            ← all styles
    └── js/app.js                ← modals, AJAX flag submit, table search
```

---

## What persists in MySQL

| Table | Stores |
|-------|--------|
| `users` | Full name, username, bcrypt-hashed password, role, join date |
| `challenges` | All 10 CTF tasks including flags (students never see flags) |
| `submissions` | Every flag attempt — correct and wrong — with timestamps |
| `settings` | Image filename and SHA256 hash for student verification |

Every time a student logs in from any device, they see exactly their own history pulled live from MySQL.

---

## Admin Features

| Feature | Location |
|---------|----------|
| View all scores and rankings | Admin → Scoreboard |
| See any student's full per-challenge progress | Click any row in Scoreboard or Students, or click 📊 Progress button |
| Add a student manually | Admin → Students → + Add Student |
| Reset a student's password | Admin → Students → Reset PW |
| Remove a student | Admin → Students → Remove |
| View all flags (admin-only) | Admin → Challenges |
| Set image filename and hash | Admin → Settings |
| See recent submissions live | Admin → Overview |

---

## How to Add a New Challenge

1. Open `sql/challenges.sql`
2. Add a new `INSERT` row following the same format as the existing 10
3. Go to phpMyAdmin → select `cywrax_ctf` → run the new INSERT statement
   OR run: `mysql -u root cywrax_ctf < sql/challenges.sql` (will re-seed all 10 + your new one)

No PHP code needs to change — the site renders challenges dynamically from the database.

---

## How to Run on WAMP / Laragon

Same steps as XAMPP. The only difference:
- WAMP root folder: `C:\wamp64\www\cywrax\`
- Laragon root folder: `C:\laragon\www\cywrax\`

---

## How to Deploy Online (Free Hosting)

1. Create free account at **InfinityFree** (infinityfree.net) or **000webhost**
2. Upload all files via FTP or File Manager
3. Create a MySQL database in the hosting control panel
4. Visit `https://yourdomain.com/cywrax/install/` and fill in the hosting DB credentials
5. Delete the `install/` folder after setup

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| Blank page / DB error | Check `DB_HOST`, `DB_USER`, `DB_PASS` in `includes/config.php` |
| 404 on all pages | Check `BASE_URL` in `includes/config.php` matches your folder path |
| Login loops back | Make sure session is working — check `php.ini` session settings |
| Flag submit does nothing | Open browser DevTools → Network tab — check the AJAX response |
| Can't see admin panel | Make sure you're logging in with the `admin` username |

---

## Security Notes

- Passwords are hashed with **bcrypt** (cost 12) — never stored as plaintext
- All user inputs are sanitised with `htmlspecialchars()` and PDO prepared statements
- CSRF tokens on every form
- Students can never see flags — flags are only in the database and the admin Challenges page
- Delete `install/` after first run

---

## Default Credentials

| Role | Username | Password |
|------|----------|----------|
| Admin | `admin` | whatever you set during install |
| Student | (signup) | (student chooses) |
