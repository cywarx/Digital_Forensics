/* ==========================================================
   CYWARX CTF — Frontend JS
   ========================================================== */
'use strict';

/* ── Modal helpers ─────────────────────────────────────── */
function openModal(id)  { const m=document.getElementById('modal-'+id); if(m) m.classList.add('open'); }
function closeModal(id) { const m=document.getElementById('modal-'+id); if(m) m.classList.remove('open'); }

document.addEventListener('click', e => {
  if (e.target.classList.contains('modal-bg')) e.target.classList.remove('open');
});
document.addEventListener('keydown', e => {
  if (e.key === 'Escape')
    document.querySelectorAll('.modal-bg.open').forEach(m => m.classList.remove('open'));
});

/* ── Show / hide .msg element ───────────────────────────── */
function showMsg(el, text, type = 'error') {
  if (!el) return;
  el.className = 'msg ' + type + ' show';
  el.innerHTML = text;
}
function hideMsg(el) { if (el) el.classList.remove('show'); }

/* ── Challenge detail modal ─────────────────────────────── */
let currentChallengeId = null;

function openChallenge(id) {
  currentChallengeId = id;
  const msg = document.getElementById('flag-msg');
  const inp = document.getElementById('flag-input');
  const btn = document.getElementById('flag-btn');
  if (msg) hideMsg(msg);
  if (inp) { inp.value = ''; inp.disabled = false; inp.placeholder = 'Cywarx{your_flag_here}'; }
  if (btn) btn.disabled = false;
  openModal('challenge');
}

// Enter key on flag input
document.addEventListener('DOMContentLoaded', () => {
  const inp = document.getElementById('flag-input');
  if (inp) inp.addEventListener('keydown', e => { if (e.key==='Enter') submitFlag(); });
});

function submitFlag() {
  const inp = document.getElementById('flag-input');
  const msg = document.getElementById('flag-msg');
  const btn = document.getElementById('flag-btn');
  if (!inp || !currentChallengeId) return;

  const val = inp.value.trim();
  if (!val) { showMsg(msg, 'Please enter a flag.', 'error'); return; }

  btn.disabled = true;
  btn.textContent = 'Checking…';

  fetch(BASE_URL + '/pages/submit_flag.php', {
    method : 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body   : 'challenge_id=' + encodeURIComponent(currentChallengeId)
           + '&flag=' + encodeURIComponent(val)
           + '&csrf=' + encodeURIComponent(CSRF_TOKEN),
  })
  .then(r => r.json())
  .then(data => {
    if (data.ok) {
      showMsg(msg, '🎉 Correct! +' + data.pts + ' points awarded!', 'success');
      inp.disabled = true;
      btn.textContent = 'Solved!';
      // Mark card as solved
      const card = document.getElementById('ch-card-' + currentChallengeId);
      if (card) {
        card.classList.add('solved');
        if (!card.querySelector('.ch-solved-mark')) {
          const mk = document.createElement('div');
          mk.className = 'ch-solved-mark';
          mk.textContent = '✓ SOLVED';
          card.appendChild(mk);
        }
      }
      // Update score in nav
      if (data.total_pts !== undefined) {
        const sc = document.getElementById('nav-score');
        if (sc) sc.textContent = data.total_pts + ' pts';
      }
    } else {
      showMsg(msg, data.error || 'Wrong flag. Keep trying!', data.already ? 'info' : 'error');
      btn.disabled = false;
      btn.textContent = 'Submit';
    }
  })
  .catch(() => {
    showMsg(msg, 'Network error. Please try again.', 'error');
    btn.disabled = false;
    btn.textContent = 'Submit';
  });
}

/* ── Admin: student progress modal ─────────────────────── */
function openProgress(userId) {
  const body = document.getElementById('progress-body');
  if (!body) return;
  body.innerHTML = '<div style="text-align:center;padding:30px;color:var(--txt2);">Loading…</div>';
  openModal('progress');

  fetch(BASE_URL + '/pages/admin/student_progress.php?id=' + encodeURIComponent(userId))
    .then(r => r.text())
    .then(html => { body.innerHTML = html; })
    .catch(() => { body.innerHTML = '<div style="color:var(--red);padding:20px;">Failed to load.</div>'; });
}

/* ── Table search filter ─────────────────────────────────── */
function filterTable(inputEl, tbodyId) {
  const q    = inputEl.value.toLowerCase();
  const rows = document.querySelectorAll('#' + tbodyId + ' tr');
  rows.forEach(tr => {
    tr.style.display = tr.textContent.toLowerCase().includes(q) ? '' : 'none';
  });
}

/* ── Admin: open reset-password modal ───────────────────── */
function openResetPw(userId, name) {
  document.getElementById('reset-uid').value   = userId;
  document.getElementById('reset-name').textContent = name;
  document.getElementById('reset-pw').value    = '';
  const msg = document.getElementById('reset-msg');
  if (msg) hideMsg(msg);
  openModal('reset-pw');
}

/* ── Admin: open remove-student modal ───────────────────── */
function openRemove(userId, name) {
  document.getElementById('remove-uid').value         = userId;
  document.getElementById('remove-student-name').textContent = name;
  openModal('remove');
}
